import os

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg_share = get_package_share_directory('dbpendulum')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    xacro_file = os.path.join(pkg_share, 'urdf', 'dbpendulum.urdf.xacro')
    params_file = os.path.join(pkg_share, 'config', 'dbpendulum_params.yaml')
    bridge_file = os.path.join(pkg_share, 'config', 'dbpendulum_bridge.yaml')
    rviz_file = os.path.join(pkg_share, 'rviz', 'dbpendulum.rviz')
    world_file = os.path.join(pkg_share, 'worlds', 'dbpendulum_world.sdf')

    with open(params_file, 'r') as f:
        params = yaml.safe_load(f)['/**']['ros__parameters']
    xacro_args = ' '.join(f'{k}:={v}' for k, v in params.items())

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file, ' ', xacro_args]),
        value_type=str,
    )

    # Custom world (same gz-sim default GUI/light/ground-plane setup as the
    # stock empty.sdf, just with the camera pointed at a front view of the
    # pendulum's swing plane instead of the default diagonal angle -- see
    # worlds/dbpendulum_world.sdf.
    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': [world_file, ' -r']}.items(),
    )

    return LaunchDescription([
        gz_sim,
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description, 'use_sim_time': True}],
        ),
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-topic', 'robot_description', '-name', 'dbpendulum', '-z', '0'],
            output='screen',
        ),
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            parameters=[{'config_file': bridge_file, 'use_sim_time': True}],
            output='screen',
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', rviz_file],
            parameters=[{'use_sim_time': True}],
        ),
    ])

import os
from glob import glob

from setuptools import setup

package_name = 'twolink'

setup(
    name=package_name,
    version='0.0.1',
    packages=[],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'config'), glob('config/*')),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Pranav',
    maintainer_email='you@example.com',
    description='Two-link planar manipulator: joint-level control via joint_state_publisher_gui sliders',
    license='Apache-2.0',
    tests_require=['pytest'],
)

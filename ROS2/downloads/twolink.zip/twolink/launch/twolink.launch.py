import os

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg_share = get_package_share_directory('twolink')
    xacro_file = os.path.join(pkg_share, 'urdf', 'twolink.urdf.xacro')
    params_file = os.path.join(pkg_share, 'config', 'twolink_params.yaml')
    rviz_file = os.path.join(pkg_share, 'rviz', 'twolink.rviz')

    with open(params_file, 'r') as f:
        params = yaml.safe_load(f)['/**']['ros__parameters']
    l1 = str(params['l1'])
    l2 = str(params['l2'])

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file, ' l1:=', l1, ' l2:=', l2]),
        value_type=str,
    )

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description}],
        ),
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', rviz_file],
        ),
    ])

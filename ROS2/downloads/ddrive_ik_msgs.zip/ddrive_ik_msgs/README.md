# ddrive_ik_msgs

Custom interfaces for the `ddrive` / `ddrive_ik` course: no nodes, no
Python — just message definitions that other packages build against.

| File | Kind | Used by (planned) |
|---|---|---|
| `srv/ResetPose.srv` | service | a future service server in `ddrive_sim` (package `ddrive`), to snap the robot back to a given pose without restarting the node |
| `action/TrackTrajectory.action` | action | a future action server in `ddrive_ik`, to track the reference curve for a bounded number of loops with feedback and cancellation |

## Why this needs its own package

Every node in this course so far is `ament_python`. Interface
generation (`.srv`/`.action` → real message classes) is done by
`rosidl_generate_interfaces`, which only runs in an `ament_cmake`
package. That's a real ROS 2 constraint, not a style choice — this
package exists purely to satisfy it, and has no Python code of its own.

## Build

```bash
cp -r ddrive_ik_msgs ~/ros2_ws/src/
cd ~/ros2_ws
source /opt/ros/$ROS_DISTRO/setup.bash
colcon build --packages-select ddrive_ik_msgs
source install/setup.bash
```

Checkpoint — confirm the generated interfaces exist:
```bash
ros2 interface show ddrive_ik_msgs/srv/ResetPose
ros2 interface show ddrive_ik_msgs/action/TrackTrajectory
```

## ResetPose.srv

```text
float64 x
float64 y
float64 theta
---
bool success
string message
```

## TrackTrajectory.action

```text
int32 num_loops
---
float64 total_time
float64 final_error
---
int32 loops_completed
float64 current_error
```

## What's next

Nothing calls these yet — this package is just the interface
definitions. Next step: add a `ResetPose` service *server* to
`ddrive_sim` (in the `ddrive` package, since that's the node that owns
the pose state), and a `TrackTrajectory` action *server* to a new node
in `ddrive_ik`. Both of those packages will need `ddrive_ik_msgs` added
as a dependency once that code exists.

import os

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg_share = get_package_share_directory('dbpendulum_ctrl')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    xacro_file = os.path.join(pkg_share, 'urdf', 'dbpendulum_ctrl.urdf.xacro')
    params_file = os.path.join(pkg_share, 'config', 'dbpendulum_ctrl_params.yaml')
    controllers_file = os.path.join(pkg_share, 'config', 'dbpendulum_ctrl_controllers.yaml')
    rviz_file = os.path.join(pkg_share, 'rviz', 'dbpendulum_ctrl.rviz')
    world_file = os.path.join(pkg_share, 'worlds', 'dbpendulum_ctrl_world.sdf')

    with open(params_file, 'r') as f:
        all_params = yaml.safe_load(f)['/**']['ros__parameters']
    # Only the physical params (m1..l) go into the URDF as xacro args; the
    # gains (kp*/kd*) and control_rate are the control node's own ROS
    # parameters, loaded straight from params_file below.
    xacro_phys_args = ' '.join(
        f'{k}:={all_params[k]}' for k in ('m1', 'm2', 'I1', 'I2', 'c1', 'c2', 'l'))

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file, ' ', xacro_phys_args,
                 ' controllers_yaml:=', controllers_file]),
        value_type=str,
    )

    # Same front-view world dbpendulum uses (gz-sim's stock GUI/light/ground
    # plane, camera aimed down the swing plane) -- no gravity override, so
    # gz-sim's default -9.8 applies, matching the g used in params_file.
    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': [world_file, ' -r']}.items(),
    )

    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description, 'use_sim_time': True}],
    )

    gz_spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-topic', 'robot_description', '-name', 'dbpendulum_ctrl', '-z', '0'],
        output='screen',
    )

    # gz_ros2_control's embedded controller_manager doesn't exist until the
    # model (and its <gazebo><plugin>gz_ros2_control...) is actually spawned.
    # An earlier version chained these spawners off gz_spawn_entity's
    # OnProcessExit event; in practice that chain never reliably fired (the
    # second link never ran even once the first controller was confirmed
    # active), so this instead just launches every spawner directly and
    # lets --controller-manager-timeout do the waiting/retrying against the
    # embedded controller_manager service until it's ready -- simpler, and
    # each spawner's failure/success is now independent and visible on its
    # own, rather than silently gating on another process's exit.
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager-timeout', '60'],
        output='screen',
    )
    # effort_controller needs its own 'joints'/'interface_name' parameters
    # (set in dbpendulum_ctrl_controllers.yaml) pushed to it explicitly via
    # --param-file at spawn time -- unlike joint_state_broadcaster, which
    # needs no controller-specific parameters beyond its type. Without this,
    # the spawner's load_controller call fails validation (missing/empty
    # 'joints') and the controller never appears in `ros2 control
    # list_controllers` at all, silently -- exactly the bug this fixes.
    effort_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['effort_controller', '--param-file', controllers_file,
                   '--controller-manager-timeout', '60'],
        output='screen',
    )

    # /clock is the only gz-transport <-> ROS2 bridge needed: joint states
    # and effort commands are already native ROS2 topics/services via
    # gz_ros2_control's controller_manager (unlike dbpendulum, which bridges
    # /joint_states directly from a gz-sim system plugin).
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    control_node = Node(
        package='dbpendulum_ctrl',
        executable='control_node',
        parameters=[params_file, {'use_sim_time': True}],
        output='screen',
    )

    node_rviz = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_file],
        parameters=[{'use_sim_time': True}],
    )

    return LaunchDescription([
        gz_sim,
        bridge,
        node_robot_state_publisher,
        gz_spawn_entity,
        joint_state_broadcaster_spawner,
        effort_controller_spawner,
        control_node,
        node_rviz,
    ])

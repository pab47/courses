"""Feedback-linearization trajectory-tracking controller for dbpendulum_ctrl.

Ports two things from the course reference script (4b_doublependulum_
trajectory_tracking/twoink_main.py) essentially unchanged:

  1. The point-to-point reference trajectory: theta1 moves along a single
     cubic-polynomial segment over t in [0, 3]s; theta2 moves out and back
     along two cubic segments (t in [0, 1.5]s, then [1.5, 3]s) matched in
     position/velocity/acceleration at the seam. The literal coefficients
     below are copied from the script's own printed values (derived there
     via link1_traj.py / link2_traj.py's sympy boundary-value solve).

  2. The control() function: the "control partitioning" (computed-torque /
     feedback-linearization) law
         T = M(theta) * (qddot_ref - Kp*(theta-theta_ref) - Kd*(thetadot-thetadot_ref)) + C(theta,thetadot) + G(theta)
     using the exact same M11/M12/M21/M22/C1/C2/G1/G2 closed-form
     expressions as the reference script.

This only works because dbpendulum_ctrl's URDF (urdf/dbpendulum_ctrl.urdf.
xacro) was deliberately built so that joint1's raw state IS theta1 (link1's
absolute angle from the world +X axis) and joint2's raw state IS theta2
(link2's angle relative to link1) -- exactly the convention twolink_eom.py
derived M/C/G in. dbpendulum's own URDF uses a different, incompatible
convention (built for a different, uncontrolled/chaotic demo); don't reuse
this control node against that URDF.
"""
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray

PI = math.pi

# --- theta1: single cubic segment, t in [T1_0, T1_N] ---
T1_0, T1_N = 0.0, 3.0
A10, A11, A12, A13 = -0.5 * PI - 0.5, 0.0, 0.333333333333333, -0.0740740740740741

# --- theta2: two cubic segments, matched in position/velocity/accel at the seam ---
T2A_0, T2A_N = 0.0, 1.5
T2B_0, T2B_N = 1.5, 3.0
B10, B11, B12, B13 = (
    0.0,
    0.0,
    0.666666666666667 - 0.666666666666667 * PI,
    -0.296296296296296 + 0.296296296296296 * PI,
)
B20, B21, B22, B23 = (
    -2.0 + 2.0 * PI,
    4.0 - 4.0 * PI,
    -2.0 + 2.0 * PI,
    0.296296296296296 - 0.296296296296296 * PI,
)

TORQUE_LIMIT = 200.0  # N*m, matches the <command_interface> min/max in the URDF


def _cubic(t, a0, a1, a2, a3):
    return (a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3,
            a1 + 2 * a2 * t + 3 * a3 * t ** 2,
            2 * a2 + 6 * a3 * t)


def traj1(t):
    """theta1_ref, theta1dot_ref, theta1ddot_ref at time t."""
    if t < T1_0:
        pos, _, _ = _cubic(T1_0, A10, A11, A12, A13)
        return pos, 0.0, 0.0
    if t > T1_N:
        pos, _, _ = _cubic(T1_N, A10, A11, A12, A13)
        return pos, 0.0, 0.0
    return _cubic(t, A10, A11, A12, A13)


def traj2(t):
    """theta2_ref, theta2dot_ref, theta2ddot_ref at time t."""
    if t < T2A_0:
        pos, _, _ = _cubic(T2A_0, B10, B11, B12, B13)
        return pos, 0.0, 0.0
    if t <= T2A_N:
        return _cubic(t, B10, B11, B12, B13)
    if t > T2B_N:
        pos, _, _ = _cubic(T2B_N, B20, B21, B22, B23)
        return pos, 0.0, 0.0
    return _cubic(t, B20, B21, B22, B23)


class DbpendulumCtrl(Node):

    def __init__(self):
        super().__init__('dbpendulum_ctrl')

        self.declare_parameter('m1', 1.0)
        self.declare_parameter('m2', 1.0)
        self.declare_parameter('I1', 0.1)
        self.declare_parameter('I2', 0.1)
        self.declare_parameter('c1', 0.5)
        self.declare_parameter('c2', 0.5)
        self.declare_parameter('l', 1.0)
        self.declare_parameter('g', 9.8)
        self.declare_parameter('kp1', 100.0)
        self.declare_parameter('kd1', 20.0)
        self.declare_parameter('kp2', 100.0)
        self.declare_parameter('kd2', 20.0)
        self.declare_parameter('control_rate', 200.0)

        gp = self.get_parameter
        self.m1 = gp('m1').value
        self.m2 = gp('m2').value
        self.I1 = gp('I1').value
        self.I2 = gp('I2').value
        self.c1 = gp('c1').value
        self.c2 = gp('c2').value
        self.l = gp('l').value
        self.g = gp('g').value
        self.kp1 = gp('kp1').value
        self.kd1 = gp('kd1').value
        self.kp2 = gp('kp2').value
        self.kd2 = gp('kd2').value
        control_rate = gp('control_rate').value

        self._theta1 = None
        self._theta1dot = None
        self._theta2 = None
        self._theta2dot = None
        self._t0 = None

        self._sub = self.create_subscription(
            JointState, 'joint_states', self._joint_state_cb, 10)
        self._pub = self.create_publisher(
            Float64MultiArray, 'effort_controller/commands', 10)
        self._timer = self.create_timer(1.0 / control_rate, self._control_tick)

        self.get_logger().info(
            'dbpendulum_ctrl running: tracking twoink_main.py\'s reference '
            'trajectory (theta1 over [0,3]s, theta2 over [0,1.5,3]s) with '
            'feedback linearization.')

    def _joint_state_cb(self, msg):
        for name, pos, vel in zip(msg.name, msg.position, msg.velocity):
            if name == 'joint1':
                self._theta1, self._theta1dot = pos, vel
            elif name == 'joint2':
                self._theta2, self._theta2dot = pos, vel

    def _have_state(self):
        return None not in (self._theta1, self._theta1dot,
                             self._theta2, self._theta2dot)

    def _control(self, theta1, theta1dot, theta2, theta2dot,
                 theta1ref, theta1dotref, theta1ddotref,
                 theta2ref, theta2dotref, theta2ddotref):
        """Direct port of twoink_main.py's control(): feedback-linearization
        (computed-torque) control partitioning, unmodified."""
        m1, I1, c1 = self.m1, self.I1, self.c1
        m2, I2, c2 = self.m2, self.I2, self.c2
        l, g = self.l, self.g
        cos = math.cos
        sin = math.sin

        M11 = 1.0 * I1 + 1.0 * I2 + c1 ** 2 * m1 + m2 * (c2 ** 2 + 2 * c2 * l * cos(theta2) + l ** 2)
        M12 = 1.0 * I2 + c2 * m2 * (c2 + l * cos(theta2))
        M21 = M12
        M22 = 1.0 * I2 + c2 ** 2 * m2

        C1 = -c2 * l * m2 * theta2dot * (2.0 * theta1dot + 1.0 * theta2dot) * sin(theta2)
        C2 = c2 * l * m2 * theta1dot ** 2 * sin(theta2)

        G1 = g * (c1 * m1 * cos(theta1) + m2 * (c2 * cos(theta1 + theta2) + l * cos(theta1)))
        G2 = c2 * g * m2 * cos(theta1 + theta2)

        e1, e2 = theta1 - theta1ref, theta2 - theta2ref
        ed1, ed2 = theta1dot - theta1dotref, theta2dot - theta2dotref

        u1 = theta1ddotref - self.kp1 * e1 - self.kd1 * ed1
        u2 = theta2ddotref - self.kp2 * e2 - self.kd2 * ed2

        T1 = M11 * u1 + M12 * u2 + C1 + G1
        T2 = M21 * u1 + M22 * u2 + C2 + G2
        return T1, T2

    def _control_tick(self):
        if not self._have_state():
            return
        now = self.get_clock().now()
        if self._t0 is None:
            self._t0 = now
        t = (now - self._t0).nanoseconds * 1e-9

        th1r, th1dr, th1ddr = traj1(t)
        th2r, th2dr, th2ddr = traj2(t)

        T1, T2 = self._control(
            self._theta1, self._theta1dot, self._theta2, self._theta2dot,
            th1r, th1dr, th1ddr, th2r, th2dr, th2ddr)

        T1 = max(-TORQUE_LIMIT, min(TORQUE_LIMIT, T1))
        T2 = max(-TORQUE_LIMIT, min(TORQUE_LIMIT, T2))

        msg = Float64MultiArray()
        msg.data = [T1, T2]
        self._pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = DbpendulumCtrl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'ddrive'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
        (os.path.join('share', package_name, 'config'),
            glob(os.path.join('config', '*.yaml'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Pranav',
    maintainer_email='pranav@example.com',
    description=(
        'A minimal turtlesim-style differential-drive simulator: a sim '
        'node that integrates pose, and a viz node that draws it.'
    ),
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ddrive_sim = ddrive.sim_node:main',
            'ddrive_viz = ddrive.viz_node:main',
            'ddrive_reset_pose_client = ddrive.reset_pose_client:main',
        ],
    },
)

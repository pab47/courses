# ddrive

Two nodes. That's the whole package.

| Node | Owns | Subscribes | Publishes |
|---|---|---|---|
| `ddrive_sim` | the pose `[x, y, theta]`, the integrator | `/cmd_vel` (`geometry_msgs/Twist`) | `/pose` (`geometry_msgs/Pose2D`) |
| `ddrive_viz` | nothing — just draws | `/pose` | — (opens a matplotlib window) |

`ddrive_sim` works perfectly well with nobody ever publishing to
`/cmd_vel` — it just holds still at its initial pose and keeps
publishing that pose every `dt` seconds. That's what makes the staged
workflow below possible: you can *see* the system before you *drive*
it.

## Build

```bash
mkdir -p ~/ros2_ws/src
cp -r ddrive ~/ros2_ws/src/
cd ~/ros2_ws
source /opt/ros/foxy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --packages-select ddrive
source install/setup.bash
```
(`pip3 install matplotlib numpy` first if you don't have them.)

Checkpoint: `ros2 pkg executables ddrive` should list `ddrive ddrive_sim`
and `ddrive ddrive_viz` — nothing else.

---

## Stage 1 — initialize the pose, look at it (2 terminals)

**Terminal 1:**
```bash
ros2 run ddrive ddrive_sim
```
By default the pose starts at the origin, facing along +x
(`x0=0, y0=0, theta0=0`). Override it if you want to prove to yourself
it's actually a parameter, not a hard-coded value:
```bash
ros2 run ddrive ddrive_sim --ros-args -p x0:=1.0 -p y0:=-0.5 -p theta0:=1.5708
```

**Terminal 2:**
```bash
ros2 run ddrive ddrive_viz
```
A matplotlib window opens with the robot sitting still, exactly at
whatever pose you initialized in Terminal 1. Nothing moves. This is
the whole point of stage 1: two independent processes agree on one
topic (`/pose`) and that's already enough to visualize state.

Confirm it's really live, not a static image — kill and restart
Terminal 1 with a different `x0`, restart Terminal 2, and the robot
should appear in the new spot.

## Stage 2 — command a velocity, watch it move (add a 3rd terminal)

Keep Terminals 1 and 2 running. Open a **Terminal 3** and publish a
velocity command directly from the CLI — no extra node needed yet:
```bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.3}, angular: {z: 0.2}}" -r 10
```
Watch the matplotlib window: the robot should immediately start
tracing a curved path, in real time. Ctrl+C Terminal 3 to stop
publishing — the robot keeps the last velocity it received (that's a
property of `ddrive_sim`: it never resets to zero on its own), so
publish a zero command to actually stop it:
```bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.0}, angular: {z: 0.0}}" -1
```
(`-1` = publish once and exit, vs. `-r 10` = repeat at 10 Hz.)

Try a few different commands to build intuition:
```bash
# straight line
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.5}}" -r 10
# spin in place
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{angular: {z: 1.0}}" -r 10
# arc
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.4}, angular: {z: 0.5}}" -r 10
```
When you Ctrl+C `ddrive_viz` (Terminal 2), it saves the full trail to
`ddrive_trajectory.png` in your current directory.

## Stage 3 — collapse terminals 1+2 into a launch file

Once stage 1 and 2 make sense as separate steps, this is the natural
next question: "do I really need two terminals just to bring up the
static pair?" No:
```bash
ros2 launch ddrive ddrive_launch.py
```
Same as running `ddrive_sim` + `ddrive_viz` together. Initial pose and
`dt` are launch arguments:
```bash
ros2 launch ddrive ddrive_launch.py x0:=1.0 theta0:=1.5708 dt:=0.05
```
Terminal 3 (the `ros2 topic pub` command) stays separate — that's
deliberate, not an oversight. Keeping "what exists" (the launch file)
and "what I'm doing to it right now" (a manual command) as different
terminals is exactly the mental model worth students internalizing
before you ever hand them a scripted driver node.

## Introspection, once stages 1–3 feel natural

```bash
ros2 node list
ros2 node info /ddrive_sim
ros2 topic info /cmd_vel --verbose
rqt_graph          # if installed — draws the picture above
```

## What's deliberately *not* in this version

No scripted "driver" node replaying your original letter-writing
maneuver, no custom message type, no tf broadcasting, no teleop. All
good candidates for "next feature" once stages 1–3 are second nature —
say the word for any of them.

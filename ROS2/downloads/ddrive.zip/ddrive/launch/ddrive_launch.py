from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    args = [
        DeclareLaunchArgument('dt', default_value='0.1'),
        DeclareLaunchArgument('x0', default_value='0.0'),
        DeclareLaunchArgument('y0', default_value='0.0'),
        DeclareLaunchArgument('theta0', default_value='0.0'),
        DeclareLaunchArgument('robot_radius', default_value='0.2'),
    ]
    dt = LaunchConfiguration('dt')
    x0 = LaunchConfiguration('x0')
    y0 = LaunchConfiguration('y0')
    theta0 = LaunchConfiguration('theta0')
    robot_radius = LaunchConfiguration('robot_radius')

    return LaunchDescription(args + [
        Node(
            package='ddrive',
            executable='ddrive_sim',
            name='ddrive_sim',
            parameters=[{'dt': dt, 'x0': x0, 'y0': y0, 'theta0': theta0}],
            output='screen',
        ),
        Node(
            package='ddrive',
            executable='ddrive_viz',
            name='ddrive_viz',
            parameters=[{'robot_radius': robot_radius}],
            output='screen',
        ),
    ])

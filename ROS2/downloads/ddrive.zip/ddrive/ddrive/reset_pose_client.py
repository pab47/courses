"""
ddrive_reset_pose_client — a small terminal client for ResetPose.

Usage:
    ros2 run ddrive ddrive_reset_pose_client <x> <y> <theta>

Unlike everything else in this course, this "node" only exists for the
length of one service call — it connects, sends one request, prints the
response, and exits. That's normal for a service client: there's no
ongoing relationship the way a subscriber has with a publisher.
"""

import sys

import rclpy
from rclpy.node import Node

from ddrive_ik_msgs.srv import ResetPose


class ResetPoseClient(Node):

    def __init__(self):
        super().__init__('reset_pose_client')
        self._client = self.create_client(ResetPose, 'reset_pose')

    def call(self, x, y, theta):
        while not self._client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('waiting for reset_pose service...')

        request = ResetPose.Request()
        request.x = x
        request.y = y
        request.theta = theta

        future = self._client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        return future.result()


def main(args=None):
    rclpy.init(args=args)

    if len(sys.argv) != 4:
        print('usage: ros2 run ddrive ddrive_reset_pose_client <x> <y> <theta>')
        rclpy.shutdown()
        return

    x, y, theta = (float(a) for a in sys.argv[1:4])

    node = ResetPoseClient()
    result = node.call(x, y, theta)
    node.get_logger().info(f'success={result.success}, message="{result.message}"')
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

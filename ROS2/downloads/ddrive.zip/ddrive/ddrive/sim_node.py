"""
ddrive_sim — the only node that knows about the kinematic model.

State it owns: z = [x, y, theta].

  * On startup, z is set from the parameters x0/y0/theta0 (all default
    to 0.0 if you don't set them — "default if not set" per spec).
  * Every dt seconds, a timer advances z with euler_step() using
    whatever [v, omega] was last received on 'cmd_vel' (default [0, 0]
    if nothing has ever been published — the robot just sits at its
    initial pose).
  * The resulting pose is published on 'pose' as geometry_msgs/Pose2D,
    every dt seconds, whether or not it changed.

This node alone, with nothing publishing to 'cmd_vel', is already a
complete (if boring) demo: pair it with ddrive_viz and you should see
the robot sitting still at its initial pose. That's stage 1 of the
workflow. Stage 2 is just: publish something to 'cmd_vel'.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose2D

from ddrive.kinematics import euler_step
from ddrive_ik_msgs.srv import ResetPose


class DdriveSim(Node):

    def __init__(self):
        super().__init__('ddrive_sim')

        self.declare_parameter('dt', 0.1)
        self.declare_parameter('x0', 0.0)
        self.declare_parameter('y0', 0.0)
        self.declare_parameter('theta0', 0.0)

        self._dt = self.get_parameter('dt').value
        self._z = [
            self.get_parameter('x0').value,
            self.get_parameter('y0').value,
            self.get_parameter('theta0').value,
        ]
        self._u = [0.0, 0.0]  # [v, omega]; stays zero until cmd_vel arrives

        self.create_subscription(Twist, 'cmd_vel', self._cmd_vel_cb, 10)
        self._pose_pub = self.create_publisher(Pose2D, 'pose', 10)
        self.create_timer(self._dt, self._step)

        # ResetPose: snap self._z to a new pose instantly, on request.
        # This is a service, not a topic, because it needs a definite
        # answer ("done" or "failed") and shouldn't race against the
        # timer's normal integration step the way publishing to cmd_vel
        # would if you tried to "fake" a reset that way.
        self.create_service(ResetPose, 'reset_pose', self._reset_pose_cb)

        self.get_logger().info(
            f'ddrive_sim started: dt={self._dt}s, initial pose={self._z}')

    def _cmd_vel_cb(self, msg: Twist):
        self._u = [msg.linear.x, msg.angular.z]

    def _step(self):
        self._z = euler_step(self._z, self._u, self._dt)
        msg = Pose2D()
        msg.x, msg.y, msg.theta = self._z
        self._pose_pub.publish(msg)

    def _reset_pose_cb(self, request, response):
        self._z = [request.x, request.y, request.theta]
        response.success = True
        response.message = (
            f'pose reset to x={request.x}, y={request.y}, theta={request.theta}')
        self.get_logger().info(response.message)
        return response


def main(args=None):
    rclpy.init(args=args)
    node = DdriveSim()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

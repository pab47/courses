"""
Differential-drive forward kinematics + explicit Euler integrator.

ROS-free on purpose: this is the same math as the euler_integration()
function in the original script, just refactored into a step function.
sim_node.py imports this — it is the entire "physics" of the package.

State  z = [x, y, theta]   (theta in radians)
Control u = [v, omega]     (v = linear speed, omega = angular speed)
"""

import math


def euler_step(z, u, dt):
    """Advance state z by one Euler step of size dt under control u."""
    x0, y0, theta0 = z
    v, omega = u

    xdot = v * math.cos(theta0)
    ydot = v * math.sin(theta0)
    thetadot = omega

    x1 = x0 + xdot * dt
    y1 = y0 + ydot * dt
    theta1 = theta0 + thetadot * dt

    return [x1, y1, theta1]

"""
ddrive_viz — draws the robot at its current pose, live.

Subscribes to 'pose'. Every message it receives — whether the robot is
sitting still at its initial pose or actively moving — gets redrawn.
Nothing here is aware of commands or the model; it only ever looks at
the pose stream, same as the original script's animate() only ever
looked at a precomputed trajectory array.

On Ctrl+C it saves the accumulated trail to a PNG.
"""

import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
from matplotlib import pyplot as plt
from rcl_interfaces.msg import SetParametersResult


class DdriveViz(Node):

    def __init__(self):
        super().__init__('ddrive_viz')

        self.declare_parameter('robot_radius', 0.1)
        self.declare_parameter('axis_limit', 2.0)
        self.declare_parameter('save_path', 'ddrive_trajectory.png')

        self._R = self.get_parameter('robot_radius').value
        self._lim = self.get_parameter('axis_limit').value
        self._save_path = self.get_parameter('save_path').value

        # Without this, `ros2 param set` would change the stored parameter
        # value but never touch self._R/_lim/_save_path — same trap as
        # ddrive_sim's dt. This callback is what makes 'ros2 param set
        # /ddrive_viz robot_radius 0.2' actually redraw a bigger robot on
        # the very next pose message, instead of silently doing nothing.
        self.add_on_set_parameters_callback(self._on_param_change)

        self._phi = np.arange(0, 2 * np.pi, 0.1)
        self._x_hist, self._y_hist = [], []

        self.create_subscription(Pose2D, 'pose', self._pose_cb, 10)

        self._fig, self._ax = plt.subplots()
        plt.ion()
        plt.show()

        self.get_logger().info('ddrive_viz started, waiting for /pose ...')

    def _on_param_change(self, params):
        for p in params:
            if p.name == 'robot_radius':
                self._R = p.value
            elif p.name == 'axis_limit':
                self._lim = p.value
            elif p.name == 'save_path':
                self._save_path = p.value
        return SetParametersResult(successful=True)

    def _pose_cb(self, msg: Pose2D):
        self._x_hist.append(msg.x)
        self._y_hist.append(msg.y)
        self._redraw(msg.x, msg.y, msg.theta)

    def _redraw(self, x, y, theta):
        ax = self._ax
        ax.clear()

        x_robot = x + self._R * np.cos(self._phi)
        y_robot = y + self._R * np.sin(self._phi)
        x2 = x + self._R * np.cos(theta)
        y2 = y + self._R * np.sin(theta)

        ax.plot([x, x2], [y, y2], color='black')          # heading line
        ax.plot(x_robot, y_robot, color='black')           # robot body
        ax.plot(self._x_hist, self._y_hist, color='red')   # trail

        ax.set_xlim(-self._lim, self._lim)
        ax.set_ylim(-self._lim, self._lim)
        ax.set_aspect('equal')
        plt.pause(0.001)

    def save_final_plot(self):
        if self._x_hist:
            self._fig.savefig(self._save_path)
            self.get_logger().info(f'saved trajectory plot to {self._save_path}')


def main(args=None):
    rclpy.init(args=args)
    node = DdriveViz()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.01)
            plt.pause(0.001)
    except KeyboardInterrupt:
        pass
    finally:
        node.save_final_plot()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

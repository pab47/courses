import math

import numpy as np
from scipy.optimize import fsolve


def forward_kinematics(l1, l2, theta1, theta2):
    """Return (origin, end of link1, end of link2) positions in the base frame.

    Same homogeneous-transform computation as the original
    manipulator_forward.py / manipulator_inverse.py scripts.
    """
    c1 = math.cos(theta1)
    c2 = math.cos(theta2)
    s1 = math.sin(theta1)
    s2 = math.sin(theta2)

    O01 = [0, 0]
    O12 = [l1, 0]

    H01 = np.array([[c1, -s1, O01[0]],
                     [s1,  c1, O01[1]],
                     [0,    0,      1]])
    H12 = np.array([[c2, -s2, O12[0]],
                     [s2,  c2, O12[1]],
                     [0,    0,      1]])
    H02 = np.matmul(H01, H12)

    o = [0, 0]

    P1 = np.array([l1, 0, 1])
    P0 = np.matmul(H01, P1)
    p = [P0[0], P0[1]]

    Q2 = np.array([l2, 0, 1])
    Q0 = np.matmul(H02, Q2)
    q = [Q0[0], Q0[1]]

    return o, p, q


def _ik_residual(theta, parms):
    l1, l2, x_ref, y_ref = parms
    theta1, theta2 = theta
    _, _, q = forward_kinematics(l1, l2, theta1, theta2)
    return q[0] - x_ref, q[1] - y_ref


def inverse_kinematics(l1, l2, x_ref, y_ref, theta_guess=(0.01, 0.5)):
    """Solve for (theta1, theta2) that place the end effector at (x_ref, y_ref).

    Reuses forward_kinematics() as the residual for fsolve, same approach
    as the original manipulator_inverse.py.
    """
    parms = [l1, l2, x_ref, y_ref]
    theta1, theta2 = fsolve(_ik_residual, theta_guess, parms)
    return theta1, theta2

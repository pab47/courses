import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

from twolink_ik.kinematics import inverse_kinematics


class IKNode(Node):
    def __init__(self):
        super().__init__('ik_node')

        self.declare_parameter('l1', 1.0)
        self.declare_parameter('l2', 1.0)
        self.declare_parameter('x_ref', 0.5)
        self.declare_parameter('y_ref', 0.5)

        l1 = self.get_parameter('l1').value
        l2 = self.get_parameter('l2').value
        x_ref = self.get_parameter('x_ref').value
        y_ref = self.get_parameter('y_ref').value

        theta1, theta2 = inverse_kinematics(l1, l2, x_ref, y_ref)
        self.get_logger().info(
            f'Target ({x_ref:.3f}, {y_ref:.3f}) with l1={l1}, l2={l2} '
            f'-> theta1={theta1:.3f} rad, theta2={theta2:.3f} rad'
        )

        self._joint_state = JointState()
        self._joint_state.name = ['joint1', 'joint2']
        self._joint_state.position = [theta1, theta2]

        self._pub = self.create_publisher(JointState, 'joint_states', 10)
        self._timer = self.create_timer(0.1, self._publish)

    def _publish(self):
        self._joint_state.header.stamp = self.get_clock().now().to_msg()
        self._pub.publish(self._joint_state)


def main(args=None):
    rclpy.init(args=args)
    node = IKNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

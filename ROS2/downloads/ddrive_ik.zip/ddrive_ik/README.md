# ddrive_ik

Trajectory tracking on top of the `ddrive` package. This package adds
two nodes and depends on `ddrive` for the other two — it does not
duplicate `ddrive_sim` or `ddrive_viz`.

| Node | Package | Subscribes | Publishes |
|---|---|---|---|
| `ddrive_sim` | `ddrive` | `/cmd_vel` | `/pose` |
| `ddrive_viz` | `ddrive` | `/pose` | — |
| `ddrive_trajectory` | **`ddrive_ik`** | — | `/reference` |
| `ddrive_controller` | **`ddrive_ik`** | `/pose`, `/reference` | `/cmd_vel` |

Both `ddrive` and `ddrive_ik` need to be in the same workspace (`src/`)
and both built, since `ddrive_ik`'s launch file starts nodes from both
packages, and its `package.xml` declares `ddrive` as an `exec_depend`.

## Build (both packages, in the same workspace)

```bash
mkdir -p ~/ros2_ws/src
cp -r ddrive ~/ros2_ws/src/         # if not already there
cp -r ddrive_ik ~/ros2_ws/src/
cd ~/ros2_ws
source /opt/ros/foxy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --packages-select ddrive ddrive_ik
source install/setup.bash
```

Checkpoint:
```bash
ros2 pkg executables ddrive
ros2 pkg executables ddrive_ik
```
should show `ddrive_sim`/`ddrive_viz` under the first and
`ddrive_trajectory`/`ddrive_controller` under the second.

## Run — staged, terminal by terminal

Every terminal needs both `source` lines:
```bash
source /opt/ros/foxy/setup.bash
source ~/ros2_ws/install/setup.bash
```

```bash
# T1 — from the ddrive package
ros2 run ddrive ddrive_sim
# T2 — from the ddrive package
ros2 run ddrive ddrive_viz
# T3 — from ddrive_ik
ros2 run ddrive_ik ddrive_trajectory
```
Nothing moves yet — `ddrive_controller` isn't running, so `/cmd_vel`
never gets published. Confirm T3 is actually publishing:
```bash
ros2 topic echo /reference
```

```bash
# T4 — from ddrive_ik
ros2 run ddrive_ik ddrive_controller
```
Watch T2's plot window: the robot swings to catch the reference point
and traces the astroid, looping every `period` seconds (default 10s).

## Run — collapsed into one launch file

```bash
ros2 launch ddrive_ik tracking_launch.py
```
Overridable args: `shape` (`astroid`/`circle`), `period`, `scale`,
`px`, `py`, `Kp`, `dt` — e.g.:
```bash
ros2 launch ddrive_ik tracking_launch.py shape:=circle period:=6.0
```

## Worth pointing out to students

- `ros2 pkg executables` on each package separately is a good way to
  show the boundary is real — `ddrive_ik` genuinely does not contain
  `ddrive_sim`.
- The controller never imports anything from the `ddrive` package —
  the *only* thing tying the two packages together at runtime is topic
  names and message types (`/pose`, `/cmd_vel`), the same decoupling
  idea as the first `ddrive` example, now spanning a package boundary.
- The `exec_depend` on `ddrive` in `ddrive_ik/package.xml` is what
  makes `rosdep`/documentation-generation tools aware of the
  dependency — it has no effect on imports, since there aren't any.
- The robot starts at the origin facing +x by default (same as
  `ddrive_sim` always has), not pre-seeded at the curve's start like
  the original script — the controller visibly "catching up" for the
  first second or two is expected, not a bug.

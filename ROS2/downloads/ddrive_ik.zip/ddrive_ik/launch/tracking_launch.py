from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    args = [
        DeclareLaunchArgument('dt', default_value='0.01'),
        DeclareLaunchArgument('shape', default_value='astroid'),
        DeclareLaunchArgument('period', default_value='10.0'),
        DeclareLaunchArgument('scale', default_value='1.0'),
        DeclareLaunchArgument('px', default_value='0.05'),
        DeclareLaunchArgument('py', default_value='0.0'),
        DeclareLaunchArgument('Kp', default_value='100.0'),
        # Initial pose for ddrive_sim, defaulted to match where the
        # reference curve starts at t=0 (point P = (scale, 0), theta=0):
        #   x0 = scale - px,  y0 = -py,  theta0 = 0
        # Recompute these if you change scale/px/py from their defaults —
        # otherwise the controller starts with a large error and the
        # Euler integrator can overshoot badly on the first few steps.
        DeclareLaunchArgument('x0', default_value='0.95'),
        DeclareLaunchArgument('y0', default_value='0.0'),
        DeclareLaunchArgument('theta0', default_value='0.0'),
    ]
    dt = LaunchConfiguration('dt')

    return LaunchDescription(args + [
        # --- from the ddrive package ---
        Node(
            package='ddrive', executable='ddrive_sim', name='ddrive_sim',
            parameters=[{
                'dt': dt,
                'x0': LaunchConfiguration('x0'),
                'y0': LaunchConfiguration('y0'),
                'theta0': LaunchConfiguration('theta0'),
            }],
            output='screen',
        ),
        Node(
            package='ddrive', executable='ddrive_viz', name='ddrive_viz',
            output='screen',
        ),
        # --- from this package, ddrive_ik ---
        Node(
            package='ddrive_ik', executable='ddrive_trajectory', name='ddrive_trajectory',
            parameters=[{
                'dt': dt,
                'shape': LaunchConfiguration('shape'),
                'period': LaunchConfiguration('period'),
                'scale': LaunchConfiguration('scale'),
            }],
            output='screen',
        ),
        Node(
            package='ddrive_ik', executable='ddrive_controller', name='ddrive_controller',
            parameters=[{
                'dt': dt,
                'px': LaunchConfiguration('px'),
                'py': LaunchConfiguration('py'),
                'Kp': LaunchConfiguration('Kp'),
            }],
            output='screen',
        ),
        Node(
            package='ddrive_ik', executable='ddrive_track_action_server',
            name='ddrive_track_action_server',
            parameters=[{
                'period': LaunchConfiguration('period'),
                'px': LaunchConfiguration('px'),
                'py': LaunchConfiguration('py'),
            }],
            output='screen',
        ),
    ])

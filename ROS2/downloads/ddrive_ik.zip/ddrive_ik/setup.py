import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'ddrive_ik'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
        (os.path.join('share', package_name, 'config'),
            glob(os.path.join('config', '*.yaml'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Pranav',
    maintainer_email='pranav@example.com',
    description=(
        'Point-offset feedback-linearization trajectory tracking for '
        'the ddrive robot: trajectory + controller nodes.'
    ),
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ddrive_trajectory = ddrive_ik.trajectory_node:main',
            'ddrive_controller = ddrive_ik.controller_node:main',
            'ddrive_track_action_server = ddrive_ik.track_trajectory_action_server:main',
            'ddrive_track_action_client = ddrive_ik.track_trajectory_client:main',
        ],
    },
)

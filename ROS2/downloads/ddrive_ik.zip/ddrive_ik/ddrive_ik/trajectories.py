"""
Reference trajectories for point P to track, as closed-form functions of
time. ROS-free — trajectory_node.py is the only thing that turns "a
curve" into a stream of ROS messages.

Each function takes t in seconds and a `period` (the time to complete
one full loop of the curve) and returns [x, y]. trajectory_node.py wraps
elapsed time modulo `period` so the curve repeats indefinitely, instead
of running once like the original script did over t0..tend.
"""

import math


def astroid(t, period, a=1.0, x_center=0.0, y_center=0.0):
    """Astroid (4-cusped hypocycloid) — same curve as diff_drive_ik.py."""
    phase = 2 * math.pi * t / period
    x = x_center + a * math.cos(phase) ** 3
    y = y_center + a * math.sin(phase) ** 3
    return [x, y]


def circle(t, period, radius=1.0, x_center=0.0, y_center=0.0):
    """A simple circle — useful as an easier first target than the astroid."""
    phase = 2 * math.pi * t / period
    x = x_center + radius * math.cos(phase)
    y = y_center + radius * math.sin(phase)
    return [x, y]

"""
ddrive_controller — the "make it happen" node.

Subscribes to both:
  * 'pose'      (published by ddrive_sim, in the ddrive package)
  * 'reference' (published by ddrive_trajectory, in this package)

On a timer, runs the control law from diff_drive_ik.py's main loop:
convert the current center pose to point P, compute the position error
against the reference, and run it through feedback_linearize() to get
[v, omega] — published on 'cmd_vel'.

Same callback-driven pattern as ddrive_sim's cmd_vel/timer split:
'_pose_cb' and '_reference_cb' just cache the latest values;
'_control_step' (the timer) is what actually reads them and acts.

This node never talks to ddrive_sim or ddrive_trajectory directly — it
only knows the topic names and message types 'pose' and 'reference'.
That's true even across the package boundary: ddrive_ik doesn't import
anything from ddrive, it only depends on it at the topic level.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, PointStamped, Twist

from ddrive_ik.kinematics import point_C_to_P, feedback_linearize


class DdriveController(Node):

    def __init__(self):
        super().__init__('ddrive_controller')

        self.declare_parameter('dt', 0.01)
        self.declare_parameter('px', 0.05)
        self.declare_parameter('py', 0.0)
        self.declare_parameter('Kp', 100.0)

        self._dt = self.get_parameter('dt').value
        self._px = self.get_parameter('px').value
        self._py = self.get_parameter('py').value
        self._Kp = self.get_parameter('Kp').value

        if self._px == 0.0:
            raise ValueError('px must be nonzero (used as a denominator)')

        self._pose = None       # [x, y, theta], from ddrive_sim
        self._reference = None  # [x_ref, y_ref], from ddrive_trajectory

        self.create_subscription(Pose2D, 'pose', self._pose_cb, 10)
        self.create_subscription(
            PointStamped, 'reference', self._reference_cb, 10)
        self._cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        self.create_timer(self._dt, self._control_step)

        self.get_logger().info(
            f'ddrive_controller started: px={self._px}, py={self._py}, Kp={self._Kp}')

    def _pose_cb(self, msg: Pose2D):
        self._pose = [msg.x, msg.y, msg.theta]

    def _reference_cb(self, msg: PointStamped):
        self._reference = [msg.point.x, msg.point.y]

    def _control_step(self):
        if self._pose is None or self._reference is None:
            return  # haven't heard from both sim and trajectory yet

        theta = self._pose[2]
        x_p, y_p = point_C_to_P(self._pose, self._px, self._py)
        error = [self._reference[0] - x_p, self._reference[1] - y_p]

        v, omega = feedback_linearize(
            error, theta, self._px, self._py, self._Kp)

        msg = Twist()
        msg.linear.x = v
        msg.angular.z = omega
        self._cmd_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = DdriveController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

"""
ddrive_trajectory — the "what should happen" node.

Publishes the reference point for the *current* time, evaluated fresh on
every tick, with elapsed time wrapped modulo `period` so the curve
repeats forever (unlike the original script's fixed t0..tend run).

This node has no idea a robot or a controller exists. It only publishes
geometry_msgs/PointStamped on 'reference' every dt seconds. Swap
'astroid' for 'circle', or write your own curve in trajectories.py, and
nothing downstream needs to change.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped

from ddrive_ik import trajectories


class DdriveTrajectory(Node):

    SHAPES = {'astroid': trajectories.astroid, 'circle': trajectories.circle}

    def __init__(self):
        super().__init__('ddrive_trajectory')

        self.declare_parameter('dt', 0.01)
        self.declare_parameter('shape', 'astroid')
        self.declare_parameter('period', 10.0)   # seconds for one full loop
        self.declare_parameter('scale', 1.0)      # radius / astroid "a"

        self._dt = self.get_parameter('dt').value
        shape_name = self.get_parameter('shape').value
        self._period = self.get_parameter('period').value
        self._scale = self.get_parameter('scale').value

        if shape_name not in self.SHAPES:
            self.get_logger().warn(
                f"unknown shape '{shape_name}', falling back to 'astroid'")
            shape_name = 'astroid'
        self._shape_fn = self.SHAPES[shape_name]

        self._pub = self.create_publisher(PointStamped, 'reference', 10)
        self._t0 = self.get_clock().now()
        self.create_timer(self._dt, self._tick)

        self.get_logger().info(
            f'ddrive_trajectory started: shape={shape_name}, '
            f'period={self._period}s, scale={self._scale}')

    def _tick(self):
        elapsed = (self.get_clock().now() - self._t0).nanoseconds * 1e-9
        t_mod = elapsed % self._period
        x_ref, y_ref = self._shape_fn(t_mod, self._period, self._scale)

        msg = PointStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'world'
        msg.point.x = x_ref
        msg.point.y = y_ref
        self._pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = DdriveTrajectory()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

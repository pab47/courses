"""
Point-offset feedback-linearization control law, from diff_drive_ik.py.

ROS-free, same philosophy as ddrive/kinematics.py: no rclpy import here,
so controller_node.py is the only thing that turns this math into ROS
messages.

Note this is a *different* kinematics.py than the one in the ddrive
package — that one has the forward-kinematics Euler integrator used by
ddrive_sim. This one has the control law used by ddrive_controller. They
live in different packages (ddrive vs. ddrive_ik) on purpose: the
integrator belongs to "how the robot moves" (ddrive), the control law
belongs to "how to steer it toward a target" (ddrive_ik). Both packages
importing something called `kinematics` and meaning different things is
intentional here — it's `ddrive.kinematics` vs. `ddrive_ik.kinematics`,
never ambiguous because the package name is part of the import path.
"""

import math


def point_C_to_P(z, px, py):
    """Map the robot-center pose z=[x,y,theta] to the controlled point P,
    offset by (px, py) in the robot's body frame. Same as ptC_to_ptP()."""
    x_c, y_c, theta = z
    cos, sin = math.cos(theta), math.sin(theta)
    x_p = x_c + px * cos - py * sin
    y_p = y_c + px * sin + py * cos
    return [x_p, y_p]


def point_P_to_C(x_p, y_p, theta, px, py):
    """Inverse of point_C_to_P — given a desired P and heading, find the
    matching robot-center position. Same as ptP_to_ptC()."""
    cos, sin = math.cos(theta), math.sin(theta)
    x_c = x_p - (px * cos - py * sin)
    y_c = y_p - (px * sin + py * cos)
    return [x_c, y_c]


def feedback_linearize(error, theta, px, py, Kp):
    """Point-offset feedback linearization: given the position error of
    point P (error = [ex, ey]), the current heading theta, the body-frame
    offset (px, py) of P from the robot center, and a proportional gain
    Kp, return the control u=[v, omega] that drives error toward zero.

    This is exactly the Ainv @ b step from diff_drive_ik.py, just written
    out as one function instead of inline numpy. px must be nonzero (it's
    in the denominator) — this is the same constraint the original script
    had, just implicit there.
    """
    bx, by = Kp * error[0], Kp * error[1]
    cos, sin = math.cos(theta), math.sin(theta)

    a11 = cos - (py / px) * sin
    a12 = sin + (py / px) * cos
    a21 = -(1.0 / px) * sin
    a22 = (1.0 / px) * cos

    v = a11 * bx + a12 * by
    omega = a21 * bx + a22 * by
    return [v, omega]

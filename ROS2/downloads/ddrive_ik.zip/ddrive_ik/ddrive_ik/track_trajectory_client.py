"""
ddrive_track_action_client — sends a TrackTrajectory goal.

Usage:
    ros2 run ddrive_ik ddrive_track_action_client <num_loops>

Unlike the ResetPose client, this one stays alive for the whole
goal — it needs to keep spinning to receive feedback messages as they
arrive, and to receive the final result. Ctrl+C sends a cancel request
instead of just quitting, so you can watch the 'goal canceled' path in
the action server's log too.
"""

import sys

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from ddrive_ik_msgs.action import TrackTrajectory


class TrackTrajectoryClient(Node):

    def __init__(self):
        super().__init__('track_trajectory_client')
        self._client = ActionClient(self, TrackTrajectory, 'track_trajectory')
        self._goal_handle = None

    def send_goal(self, num_loops):
        self._client.wait_for_server()
        goal_msg = TrackTrajectory.Goal()
        goal_msg.num_loops = num_loops

        self.get_logger().info(f'sending goal: track {num_loops} loop(s)')
        send_goal_future = self._client.send_goal_async(
            goal_msg, feedback_callback=self._feedback_cb)
        send_goal_future.add_done_callback(self._goal_response_cb)

    def _goal_response_cb(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('goal rejected')
            rclpy.shutdown()
            return

        self.get_logger().info('goal accepted')
        self._goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self._result_cb)

    def _feedback_cb(self, feedback_msg):
        fb = feedback_msg.feedback
        self.get_logger().info(
            f'feedback: loops_completed={fb.loops_completed}, '
            f'current_error={fb.current_error:.4f}')

    def _result_cb(self, future):
        result = future.result().result
        self.get_logger().info(
            f'result: total_time={result.total_time:.2f}s, '
            f'final_error={result.final_error:.4f}')
        rclpy.shutdown()

    def cancel(self):
        if self._goal_handle is not None:
            self.get_logger().info('canceling goal')
            self._goal_handle.cancel_goal_async()


def main(args=None):
    rclpy.init(args=args)

    if len(sys.argv) != 2:
        print('usage: ros2 run ddrive_ik ddrive_track_action_client <num_loops>')
        rclpy.shutdown()
        return

    num_loops = int(sys.argv[1])
    node = TrackTrajectoryClient()
    node.send_goal(num_loops)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.cancel()


if __name__ == '__main__':
    main()

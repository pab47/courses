"""
ddrive_track_action_server — hosts the TrackTrajectory action.

Important design point: this node does NOT publish cmd_vel — that's
still ddrive_controller's job, running continuously regardless of
whether any action goal is active. This node only *watches* (via 'pose'
and 'reference', the same topics ddrive_controller uses) and reports
progress against a bounded goal: "track for N loops," with periodic
feedback and a cancelable, awaitable result.

That split matters pedagogically: it shows an action doesn't have to
own the thing it's supervising. Topics keep flowing whether or not this
node exists; the action just adds a bounded, observable "session" on
top of an otherwise-endless process.

Uses a MultiThreadedExecutor (see main()) — the execute callback below
blocks with time.sleep() while polling for cancellation, which needs a
second thread free to actually process the cancel request while that's
happening. This matches the official rclpy action tutorial's guidance.
"""

import time

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, PointStamped

from ddrive_ik.kinematics import point_C_to_P
from ddrive_ik_msgs.action import TrackTrajectory


class TrackTrajectoryActionServer(Node):

    def __init__(self):
        super().__init__('ddrive_track_action_server')

        self.declare_parameter('period', 10.0)  # should match ddrive_trajectory's period
        self.declare_parameter('px', 0.05)       # should match ddrive_controller's px
        self.declare_parameter('py', 0.0)        # should match ddrive_controller's py

        self._period = self.get_parameter('period').value
        self._px = self.get_parameter('px').value
        self._py = self.get_parameter('py').value

        self._pose = None       # [x, y, theta], from ddrive_sim
        self._reference = None  # [x_ref, y_ref], from ddrive_trajectory

        self.create_subscription(Pose2D, 'pose', self._pose_cb, 10)
        self.create_subscription(
            PointStamped, 'reference', self._reference_cb, 10)

        self._action_server = ActionServer(
            self,
            TrackTrajectory,
            'track_trajectory',
            execute_callback=self._execute_cb,
            goal_callback=self._goal_cb,
            cancel_callback=self._cancel_cb,
        )

        self.get_logger().info(
            f'ddrive_track_action_server started: period={self._period}s')

    def _pose_cb(self, msg: Pose2D):
        self._pose = [msg.x, msg.y, msg.theta]

    def _reference_cb(self, msg: PointStamped):
        self._reference = [msg.point.x, msg.point.y]

    def _goal_cb(self, goal_request):
        if goal_request.num_loops <= 0:
            self.get_logger().warn('rejecting goal: num_loops must be positive')
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _cancel_cb(self, goal_handle):
        self.get_logger().info('cancel request received')
        return CancelResponse.ACCEPT

    def _current_error(self):
        if self._pose is None or self._reference is None:
            return 0.0
        x_p, y_p = point_C_to_P(self._pose, self._px, self._py)
        ex = self._reference[0] - x_p
        ey = self._reference[1] - y_p
        return (ex ** 2 + ey ** 2) ** 0.5

    def _execute_cb(self, goal_handle):
        num_loops = goal_handle.request.num_loops
        total_duration = num_loops * self._period
        self.get_logger().info(f'tracking for {num_loops} loop(s) (~{total_duration:.1f}s)')

        feedback = TrackTrajectory.Feedback()
        start = time.monotonic()

        while (time.monotonic() - start) < total_duration:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result = TrackTrajectory.Result()
                result.total_time = time.monotonic() - start
                result.final_error = self._current_error()
                self.get_logger().info('goal canceled')
                return result

            elapsed = time.monotonic() - start
            feedback.loops_completed = int(elapsed // self._period)
            feedback.current_error = self._current_error()
            goal_handle.publish_feedback(feedback)

            time.sleep(0.5)

        goal_handle.succeed()
        result = TrackTrajectory.Result()
        result.total_time = time.monotonic() - start
        result.final_error = self._current_error()
        self.get_logger().info(
            f'goal succeeded: total_time={result.total_time:.2f}s, '
            f'final_error={result.final_error:.4f}')
        return result


def main(args=None):
    rclpy.init(args=args)
    node = TrackTrajectoryActionServer()
    executor = MultiThreadedExecutor()
    try:
        rclpy.spin(node, executor=executor)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

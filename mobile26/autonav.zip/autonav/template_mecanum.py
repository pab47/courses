#!/usr/bin/env python3

import os
import sys
import time

# Which platform to deploy on: "hw" (real robot, via mentorpi_hw.py) or
# "sw" (MuJoCo simulation, via mentorpi_sw.py). Both expose the same
# open_robot() -> (robot, lidar, camera) interface, so control_loop()
# below doesn't change either way.
PLATFORM = "sw"

# MuJoCo scene XML for the "sw" platform (ignored for "hw"). Lives here
# rather than in mentorpi_sw.py so the scene choice is made in one
# place; mentorpi_sw.open_robot() just takes it as an argument.
XML_PATH = "MentorPi_sw/scenes/scene_example.xml"
XML_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    XML_PATH
)
# XML_PATH = os.path.join(
#     os.path.dirname(os.path.abspath(__file__)),
#     "Mentorpi_sw", "test_scene", "scene_one_obstacle.xml",
# )

end_time = 5.0
flag_lidar = False
flag_camera = False


# Everything except this file lives in MentorPi_sdk/. Its modules
# cross-import each other as plain top-level names (e.g. mentorpi_sw.py
# does `from lidar_sensor import Lidar2D`), so rather than turning
# MentorPi_sdk into a package and rewriting those to relative imports,
# it's simplest to just add the folder itself to sys.path -- everything
# inside it then resolves exactly as it did before the move.

if (PLATFORM == "hw"):
    _SDK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "MentorPi_hw")
    if _SDK_DIR not in sys.path:
        sys.path.insert(0, _SDK_DIR)
elif (PLATFORM == "sw"):
    _SDK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "MentorPi_sw")
    if _SDK_DIR not in sys.path:
        sys.path.insert(0, _SDK_DIR)
else:
    raise ValueError(f"Unknown platform: {PLATFORM}")

def control_loop(robot, lidar, camera):
    """
    Platform-independent control loop -- works against any robot/lidar/
    camera objects that expose this interface (hardware, via
    mentorpi_hw.py, or simulation, via mentorpi_sw.py).

    set_velocity() sends one command at a time, so you're responsible for
    the timing loop -- useful when velocity needs to change dynamically
    (e.g. based on sensor readings) instead of holding steady.

    lidar and camera follow the same "you drive the timing" pattern:
    get_data() fetches the latest reading, show() draws/updates a live
    view of it, and neither one blocks -- so all three (motion, LiDAR,
    vision) can sit in the same loop.
    """
    # Warm the plot windows
    print("Opening plot windows...")

    if (flag_lidar):
        lidar.get_data()
        lidar.show()
    if (flag_camera):
        camera.get_data()
        camera.show()

    
    linear_speed = 1
    vx = linear_speed
    vy = 0.5*linear_speed
    wz = 0.0
    run_until = time.monotonic() + end_time

    while time.monotonic() < run_until:
        robot.set_velocity(vx=vx, wz=wz, vy=vy)
        #print(f"Current velocity: {robot.get_velocity()}")
        #print(f"Current angular velocity: {robot.get_angular_velocity()}")
        #print(f"Current pose: {robot.get_pose()}")
        #print(f"Current roll, pitch, yaw: {robot.get_roll_pitch_yaw()}")
        #print(f"Current linear acceleration: {robot.get_linear_acceleration()}")
        #print(f"Current odometry: {robot.get_odometry()}")

        if (flag_lidar):
            points = lidar.get_data()
            lidar.show()
        #print(points.x_data, points.y_data, points.angle_data)

        if (flag_camera):
            frame = camera.get_data()
            camera.show()
        #print(frame.center_depth)

        time.sleep(0.1)
        #print(f"time = {time.monotonic()}")

    robot.stop()


if __name__ == "__main__":
    if PLATFORM == "sw":
        from mentorpi_sw import open_robot
        robot_cm = open_robot(XML_PATH)
    else:
        from mentorpi_hw import open_robot
        robot_cm = open_robot()

    with robot_cm as (robot, lidar, camera):
        control_loop(robot, lidar, camera)

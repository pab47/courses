#!/usr/bin/env python3

"""
Simulation-specific setup for the MentorPi robot, built on the MuJoCo
machinery from main_omnidrive.py (MujocoViewer + Lidar2D + RGBDCamera +
the velocity servo / chassis physics). Everything sim-specific lives
here, mirroring mentorpi_hw.py's role for the real robot, so that
control_loop() (in test_basic.py) can stay platform-independent.

test_basic.py's control_loop() drives its own timing loop (set_velocity()
once per iteration, then reads/shows the sensors, then sleeps) rather
than handing control to MujocoViewer.run()'s internal 60 Hz loop. So
instead of run(), SimRobot.set_velocity() advances the physics by one
control period (CONTROL_HZ) and renders during that period -- the
caller's loop (test_basic.py) ends up driving the sim's timing, same as
it drives the real robot's.

Two things worth knowing about set_velocity():

  - The velocity servo is a PD controller on velocity error, and only
    damps correctly if it's re-evaluated against the *current* qvel at
    (close to) every physics substep -- that's how MujocoViewer.run()
    used it (controller() called before every mj_step). Computing it
    once per control period and holding it fixed turns the z/roll/pitch
    damping terms into a stale, undamped force that pumps energy into
    the chassis instead of removing it (symptom: robot flies into the
    air).

  - Rendering has to happen at ~60 Hz *within* the control period, not
    once at the end of it -- rendering once per 0.1s control tick is
    only ~10 fps and looks like stop-go stutter. So the control period
    is chopped into ~1/60s sub-chunks, each stepped with a fresh servo
    evaluation and then rendered, same cadence MujocoViewer.run() uses.

SimLidar wraps lidar_sensor.Lidar2D, which now speaks the same
get_data()/show() interface as lidar_sdk.LidarSDK directly (field of
view + range, a LidarPoints result, and the same top-down matplotlib
plot with the FOV/range wedge) -- SimLidar just binds it to this
viewer's live MjData and forwards get_data()/show() to it, plus an
optional call-count throttle. show() always calls Lidar2D.show() with
*no* positional argument, so it draws the top-down matplotlib plot
rather than falling back to the legacy OpenCV radar view.

SimLidar/SimCamera's get_data() runs a fresh scan/capture on every call
by default (LIDAR_PERIOD_CALLS = CAMERA_PERIOD_CALLS = 1), same as the
hardware SDKs always returning a fresh reading -- this is the setting
to reach for first if something looks frozen. If capture is a
bottleneck later, raise those constants (or pass period_calls=N to
SimLidar/SimCamera) to only do the real work every Nth call to
get_data() and reuse the cached reading in between; show() always
redraws whatever was last captured, so the window stays responsive
either way. This is a call counter, not a time-based throttle, so it
can't end up never firing just because a short run didn't reach some
sim-time threshold.

open_robot() yields (robot, lidar, camera) objects with the same
set_velocity/stop/get_data/show interface as mentorpi_hw.py's, so
test_basic.py works unmodified against either one. Window placement
mirrors mentorpi_hw.py's layout: camera top-left, lidar bottom-left.
"""

import math
from contextlib import contextmanager
from types import SimpleNamespace

import mujoco as mj
from mujoco.glfw import glfw

from lidar_sensor import Lidar2D
from camera_sensor import RGBDCamera
from mujoco_viewer import MujocoViewer

CHASSIS_BODY_NAME = "chassis"

# How often set_velocity() advances the sim -- should roughly match the
# control loop's own pacing (test_basic.py sleeps 0.1s per iteration).
CONTROL_HZ = 10.0

# Render cadence within each set_velocity() call -- keep this at
# display refresh rate (~60 Hz) so motion looks continuous instead of
# jumping in CONTROL_HZ-sized steps.
RENDER_DT = 1.0 / 60.0

# How many get_data() calls between actual lidar scans / camera
# captures. 1 = every call (default -- always fresh, can't look
# frozen). Raise this only if capture cost becomes a real bottleneck.
LIDAR_PERIOD_CALLS = 1
CAMERA_PERIOD_CALLS = 1

# Where each sensor's plot window appears on screen.
CAMERA_WINDOW_POSITION = "top-left"
LIDAR_WINDOW_POSITION = "bottom-left"

# SimRobot.set_velocity() clips commanded body-frame velocities to these
# limits -- vx/vy in m/s, wz in rad/s -- so a runaway or overly aggressive
# controller command can't fling the chassis into an unstable regime.
# Raise/lower here to retune.
MAX_VX = 2.0
MAX_VY = 1.0
MAX_WZ = 1.0


def _velocity_servo(model, data, vx, omega, vy=0.0):
    """
    Commands body-frame velocity (vx, vy, omega) to the free-joint
    chassis: convert body velocity to world velocity, run a velocity
    servo, apply the resulting generalized forces. Ported as-is from
    main_omnidrive.py -- currently a generic omnidirectional chassis
    (doesn't yet distinguish ackermann vs. mecanum). Must be called
    every physics substep to behave as a proper servo -- see the
    module docstring.
    """
    bodyid = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, CHASSIS_BODY_NAME)
    R = data.xmat[bodyid].reshape(3, 3)

    # Body -> World
    xdot_des = R[0, 0] * vx + R[0, 1] * vy
    ydot_des = R[1, 0] * vx + R[1, 1] * vy
    thetadot_des = omega

    # Current world velocities
    xdot = data.qvel[0]
    ydot = data.qvel[1]
    zdot = data.qvel[2]
    phidot = data.qvel[3]
    psidot = data.qvel[4]
    thetadot = data.qvel[5]

    # Servo gains
    kp_xy = 200.0
    kp_theta = 80.0

    Fx = kp_xy * (xdot_des - xdot)
    Fy = kp_xy * (ydot_des - ydot)
    Fz = -10 * (0 - zdot)  # keep the robot on the ground
    Tau_x = kp_theta * (0 - phidot)
    Tau_y = kp_theta * (0 - psidot)
    Tau_z = kp_theta * (thetadot_des - thetadot)

    data.qfrc_applied[:] = 0.0
    data.qfrc_applied[0] = Fx
    data.qfrc_applied[1] = Fy
    data.qfrc_applied[2] = Fz
    data.qfrc_applied[3] = Tau_x
    data.qfrc_applied[4] = Tau_y
    data.qfrc_applied[5] = Tau_z


def _render_frame(viewer):
    viewport_width, viewport_height = glfw.get_framebuffer_size(viewer.window)
    viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)

    mj.mjv_updateScene(
        viewer.model, viewer.data, viewer.opt, None, viewer.cam,
        mj.mjtCatBit.mjCAT_ALL.value, viewer.scene,
    )
    mj.mjr_render(viewport, viewer.scene, viewer.context)

    glfw.swap_buffers(viewer.window)
    glfw.poll_events()


def _advance(viewer, duration, vx, omega, vy):
    """
    Step physics forward by `duration` seconds and render along the
    way, ~60 fps worth of frames rather than one frame at the very end.

    Within each ~1/60s render chunk, the velocity servo is recomputed
    (holding vx/vy/omega fixed, but re-reading qvel) before every
    physics substep -- same tight loop main_omnidrive.py's
    run(..., explicit_control=True) used.

    Pulled out of MujocoViewer.run() so a caller can drive its own
    timing loop (e.g. test_basic.py's control_loop) instead of letting
    run() own it.
    """
    if glfw.window_should_close(viewer.window):
        return False

    end_time = viewer.data.time + duration
    while viewer.data.time < end_time:
        chunk_start = viewer.data.time
        chunk_end = min(chunk_start + RENDER_DT, end_time)
        while viewer.data.time < chunk_end:
            _velocity_servo(viewer.model, viewer.data, vx, omega, vy)
            mj.mj_step(viewer.model, viewer.data)
        _render_frame(viewer)

    return True


def _clip(value, limit):
    return max(-limit, min(limit, value))


class SimRobot:
    """
    set_velocity/stop/get_pose, matching motion_sdk.MentorPi's interface,
    plus get_goal() -- sim-only, since there's no scene XML (and so no
    "goal") on real hardware.
    """

    def __init__(self, viewer, control_hz=CONTROL_HZ):
        self._viewer = viewer
        self._period = 1.0 / control_hz

    def set_velocity(self, vx=0.0, vy=0.0, wz=0.0):
        vx = _clip(vx, MAX_VX)
        vy = _clip(vy, MAX_VY)
        wz = _clip(wz, MAX_WZ)
        _advance(self._viewer, self._period, vx, wz, vy)

    def stop(self):
        self.set_velocity(vx=0.0, vy=0.0, wz=0.0)

    def get_pose(self, degrees=False):
        """
        Return the robot's live (x, y, theta) in world coordinates --
        same shape as motion_sdk.MentorPi.get_pose() on hardware (which
        reads it from odometry), so a control_loop() that calls
        robot.get_pose() works unmodified on either platform. theta is
        yaw about world z, in radians unless degrees=True.
        """
        data = self._viewer.data
        bodyid = mj.mj_name2id(self._viewer.model, mj.mjtObj.mjOBJ_BODY, CHASSIS_BODY_NAME)
        x, y = data.xpos[bodyid][0], data.xpos[bodyid][1]
        R = data.xmat[bodyid].reshape(3, 3)
        theta = math.atan2(R[1, 0], R[0, 0])  # yaw about world z
        if degrees:
            theta = math.degrees(theta)
        return (float(x), float(y), float(theta))

    def get_goal(self):
        """
        Return the scene's "goal" <site> position as (x, y), read from
        the already-loaded model -- so callers (e.g. test_go_to_goal.py)
        don't need to touch MuJoCo/the XML themselves. Works with
        BARN-generated scenes too, since it reads whatever the loaded
        model actually has rather than a value hardcoded elsewhere.
        """
        return self._site_xy("goal")

    def _site_xy(self, name):
        site_id = mj.mj_name2id(self._viewer.model, mj.mjtObj.mjOBJ_SITE, name)
        if site_id < 0:
            raise ValueError(f"Site {name!r} not found in the loaded scene")
        x, y = self._viewer.model.site_pos[site_id][:2]
        return (float(x), float(y))


class SimLidar:
    """
    get_data/show, matching lidar_sdk.LidarSDK's interface. Wraps
    Lidar2D (which now speaks this same interface natively) bound to
    this viewer's live MjData, plus an optional call-count throttle: by
    default every get_data() call runs a fresh raycast (period_calls=1);
    pass a higher period_calls to only scan every Nth call and reuse
    the cached reading otherwise.
    """

    def __init__(self, viewer, field_of_view_degrees=90.0,
                 range_to_see_in_meters=3.0, num_beams=180,
                 exclude_body="lidar", window_position=None,
                 period_calls=LIDAR_PERIOD_CALLS):
        self._sensor = Lidar2D(
            viewer.model, "lidar_frame", num_beams=num_beams,
            field_of_view_degrees=field_of_view_degrees,
            range_to_see_in_meters=range_to_see_in_meters,
            exclude_body=exclude_body, window_position=window_position,
            data=viewer.data,
        )
        self._period_calls = max(1, period_calls)
        self._call_count = 0

    def get_data(self):
        due = (self._call_count % self._period_calls) == 0
        self._call_count += 1
        if due:
            return self._sensor.get_data()
        return self._sensor._last_points

    def show(self):
        self._sensor.show()


class SimCamera:
    """
    get_data/show, matching vision_sdk.VisionSDK's interface. By
    default every get_data() call runs a fresh RGB-D capture
    (period_calls=1); pass a higher period_calls to only capture every
    Nth call and reuse the cached frame otherwise.
    """

    def __init__(self, viewer, width=320, height=240, camera_name="front_cam",
                 window_position=None, period_calls=CAMERA_PERIOD_CALLS):
        self._viewer = viewer
        self._sensor = RGBDCamera(
            viewer.model, camera_name, width=width, height=height,
            window_position=window_position,
        )
        self._period_calls = max(1, period_calls)
        self._call_count = 0
        self._last_rgb = None
        self._last_depth = None
        self._last_result = None

    def get_data(self):
        due = (self._call_count % self._period_calls) == 0
        self._call_count += 1
        if due:
            rgb, depth = self._sensor.capture(self._viewer.data)
            self._last_rgb, self._last_depth = rgb, depth
            h, w = depth.shape
            self._last_result = SimpleNamespace(
                rgb=rgb, depth=depth, center_depth=float(depth[h // 2, w // 2]),
            )
        return self._last_result

    def show(self):
        if self._last_rgb is not None:
            self._sensor.show(self._last_rgb, self._last_depth)

    def close(self):
        self._sensor.close()


@contextmanager
def open_robot(xml_path):
    """
    Opens the MuJoCo viewer, LIDAR, and camera, and yields
    (robot, lidar, camera) -- platform-independent callers (e.g.
    control_loop() in test_basic.py) just use the objects without
    knowing they're simulation-backed.

    xml_path: path to the MuJoCo scene XML to load. Owned by
    test_basic.py's XML_PATH so the scene choice lives in one place;
    pass an absolute path (or one resolved relative to your own cwd).
    """
    viewer = MujocoViewer(xml_path, title="MentorPi Sim", reset_keyframe="start")
    viewer.set_camera(azimuth=90, elevation=-45, distance=5, lookat=[2.5, 1.5, 0.0])

    robot = SimRobot(viewer)
    lidar = SimLidar(
        viewer, field_of_view_degrees=90.0, range_to_see_in_meters=3.0,
        window_position=LIDAR_WINDOW_POSITION,
    )
    camera = SimCamera(viewer, width=320, height=240, window_position=CAMERA_WINDOW_POSITION)

    # RGBDCamera's mj.Renderer steals the current GL context the moment
    # it's constructed, without restoring it (see the comment in
    # camera_sensor.capture()). capture() restores the context on every
    # call, but that only happens once camera.get_data() actually runs --
    # if the caller never calls it (e.g. test_basic.py's flag_camera =
    # False skips the camera entirely), the stolen context sticks around
    # and every later _render_frame() call for the main viewer draws into
    # the camera's offscreen context instead: the sim window goes blank,
    # even though nothing about it changed. Restore it here so the main
    # viewer works regardless of whether the camera is ever used.
    glfw.make_context_current(viewer.window)

    try:
        yield robot, lidar, camera
    finally:
        camera.close()
        glfw.terminate()


if __name__ == "__main__":
    from test_basic import control_loop, XML_PATH

    with open_robot(XML_PATH) as (robot, lidar, camera):
        control_loop(robot, lidar, camera)

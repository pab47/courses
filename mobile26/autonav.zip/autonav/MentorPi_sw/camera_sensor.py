"""
camera_sensor.py

Reusable RGB-D camera class for MuJoCo, in the same spirit as
lidar_sensor.py's Lidar2D: wraps MuJoCo's offscreen renderer so a
named <camera> in the model can be queried each step for color,
depth, and a world-frame point cloud, without touching the XML again
to change resolution or FOV.

Requires a working offscreen OpenGL context. Set the MUJOCO_GL
environment variable before importing mujoco if the default backend
doesn't work on your machine, e.g.:

    import os
    os.environ["MUJOCO_GL"] = "egl"   # or "osmesa", or "glfw"
"""

import numpy as np
import mujoco as mj


_SCREEN_SIZE = None


def _get_screen_size():
    """
    Best-effort screen size lookup, in pixels. Falls back to a
    reasonable default (1920x1080) if it can't be determined.

    Deliberately does NOT use tkinter for this: instantiating
    tkinter.Tk() just to read screen dimensions has been observed to
    hard-crash the whole process on some macOS/Tk combinations (an
    uncatchable native NSException -- "-[NSApplication macOSVersion]:
    unrecognized selector" -- which aborts the process before Python's
    own exception handling ever runs). Since that failure mode can't be
    caught, tkinter is avoided entirely here rather than attempted and
    guarded with try/except. (Duplicated from lidar_sensor.py rather
    than imported, so this module stays standalone/reusable on its
    own.)
    """

    global _SCREEN_SIZE

    if _SCREEN_SIZE is None:
        _SCREEN_SIZE = (1920, 1080)  # safe default if detection fails

        try:
            import platform

            if platform.system() == "Darwin":
                import subprocess

                result = subprocess.run(
                    [
                        "osascript", "-e",
                        'tell application "Finder" to get bounds of window of desktop',
                    ],
                    capture_output=True, text=True, timeout=2,
                )
                if result.returncode == 0:
                    parts = [int(p.strip()) for p in result.stdout.split(",")]
                    if len(parts) == 4:
                        _SCREEN_SIZE = (parts[2], parts[3])
        except Exception:
            pass  # keep the (1920, 1080) default

    return _SCREEN_SIZE


def _resolve_window_position(position, win_width_px, win_height_px):
    """
    Resolve a window position into (x, y) pixel coordinates.

    position can be an explicit (x, y) pixel tuple, or one of the strings
    "top-left", "top-right", "bottom-left", "bottom-right".
    """

    if position is None:
        return None

    if isinstance(position, str):
        screen_width, screen_height = _get_screen_size()
        margin = 30
        offset = 500
        offset2 = 50

        corners = {
            "top-left": (margin+offset2, margin),
            "top-right": (screen_width - win_width_px - margin-offset, margin),
            "bottom-left": (margin, screen_height - win_height_px - margin),
            "bottom-right": (
                screen_width - win_width_px - margin,
                screen_height - win_height_px - margin,
            ),
        }

        if position not in corners:
            raise ValueError(
                f"window_position string must be one of {list(corners)}, "
                f"got {position!r}"
            )

        return corners[position]

    # Assume an explicit (x, y) pixel tuple.
    return position


class RGBDCamera:
    def __init__(self, model, camera_name, width=640, height=480, window_position=None):
        """
        Parameters
        ----------
        model : mj.MjModel
        camera_name : str
            Name of the <camera> element in the XML (e.g. "front_cam").
        width, height : int
            Render resolution in pixels. Larger = slower; pick the
            smallest size that still gives you useful data.
        window_position : optional
            Where show()'s RGB window should appear -- an explicit
            (x, y) pixel tuple, or one of "top-left", "top-right",
            "bottom-left", "bottom-right". None (default) leaves it at
            a fixed (50, 50), same as before. The depth window (if
            shown) is always placed just to the right of the RGB one,
            so for "top-right"/"bottom-right" the pair may run off the
            right edge of the screen -- pick a left-side corner if you
            want both windows fully visible.
        """
        self.model = model
        self.width = width
        self.height = height
        self.window_position = window_position

        self.camid = mj.mj_name2id(model, mj.mjtObj.mjOBJ_CAMERA, camera_name)
        if self.camid < 0:
            raise ValueError(f"Camera '{camera_name}' not found in model")
        self.camera_name = camera_name

        # Pinhole intrinsics derived from the camera's vertical FOV.
        # MuJoCo cameras are always pinhole with square pixels and no
        # distortion, so this is exact (not an approximation).
        fovy_deg = model.cam_fovy[self.camid]
        self.f = 0.5 * height / np.tan(np.deg2rad(fovy_deg) / 2.0)
        self.cx = width / 2.0
        self.cy = height / 2.0

        self.renderer = mj.Renderer(model, height=height, width=width)

        # Precompute pixel grid for vectorized point-cloud unprojection
        us, vs = np.meshgrid(np.arange(width), np.arange(height))
        self._us = us.astype(np.float64)
        self._vs = vs.astype(np.float64)

    def capture(self, data):
        """
        Render both color and depth for the current sim state.

        Returns
        -------
        rgb : (height, width, 3) uint8 array
        depth : (height, width) float32 array
            Perpendicular distance from the camera plane to the
            nearest surface along each pixel's ray, in meters (this
            is depth, not Euclidean range -- the two only coincide
            exactly at the center pixel).
        """
        # mj.Renderer manages its own GL context internally and makes
        # it current when rendering, WITHOUT restoring whatever was
        # current before -- this silently steals the context from an
        # interactive GLFW viewer running in the same process (their
        # swap_buffers() then targets the wrong context, producing
        # black/frozen frames). Save + restore around the render calls
        # so this class doesn't disturb the caller's own GL context.
        prev_context = None
        try:
            from mujoco.glfw import glfw
            prev_context = glfw.get_current_context()
        except Exception:
            pass  # no glfw window in this process -- nothing to preserve

        self.renderer.update_scene(data, camera=self.camera_name)
        rgb = self.renderer.render()

        self.renderer.enable_depth_rendering()
        self.renderer.update_scene(data, camera=self.camera_name)
        depth = self.renderer.render()
        self.renderer.disable_depth_rendering()

        if prev_context:
            glfw.make_context_current(prev_context)

        return rgb, depth

    def capture_points_world(self, data):
        """
        Same as capture(), but also back-projects every pixel's depth
        into a world-frame 3D point -- the RGB-D equivalent of
        Lidar2D.scan_points_world().

        Returns
        -------
        rgb : (height, width, 3) uint8 array
        depth : (height, width) float32 array
        points_world : (height, width, 3) float64 array
            World-frame XYZ for every pixel.
        """
        rgb, depth = self.capture(data)

        # Unproject to camera-frame coordinates (OpenCV convention:
        # x right, y down, z forward -- standard for pinhole models).
        z = depth.astype(np.float64)
        x_cam = (self._us - self.cx) * z / self.f
        y_cam = (self._vs - self.cy) * z / self.f

        # MuJoCo's own camera frame convention differs from OpenCV's:
        # local +x = right, +y = up, -z = forward. Rotate our
        # (x_right, y_down, z_fwd) into that frame before applying
        # the camera's world pose.
        local_vecs = np.stack([x_cam, -y_cam, -z], axis=-1)  # (H, W, 3)

        cam_pos = data.cam_xpos[self.camid]
        cam_mat = data.cam_xmat[self.camid].reshape(3, 3)

        points_world = cam_pos + local_vecs @ cam_mat.T

        return rgb, depth, points_world

    def close(self):
        """Release the offscreen rendering context."""
        self.renderer.close()

    def show(self, rgb, depth=None, max_depth=5.0):
        """
        Display the RGB (and optionally depth) image in an OpenCV
        window. Call this once per frame from your control/render
        loop -- it does NOT block, but it does need to be called
        repeatedly (like a viewer's render loop) for the window to
        stay responsive and actually repaint.

        Parameters
        ----------
        rgb : (height, width, 3) uint8 array, as returned by capture()
        depth : (height, width) float array, optional
            If given, opens a second window with depth visualized as
            a color-mapped image (near = one end of the colormap,
            far/no-hit = the other).
        max_depth : float
            Depth values are clipped to this range before being
            scaled to 0-255 for display. Purely a visualization
            range -- does not affect the underlying depth data.
        """
        import cv2  # local import so camera_sensor.py doesn't require
                     # OpenCV unless you actually use show()

        # By default, both cv2 windows spawn at the same OS-chosen
        # position, so they land exactly on top of each other and look
        # like a single window. Position them side by side the first
        # time each is created; only once, so dragging them yourself
        # afterward doesn't get overridden every frame.
        if not hasattr(self, "_positioned_windows"):
            self._positioned_windows = set()

        rgb_win = f"{self.camera_name} - RGB"
        if rgb_win not in self._positioned_windows:
            cv2.namedWindow(rgb_win, cv2.WINDOW_AUTOSIZE)

            x, y = 50, 50
            if self.window_position is not None:
                resolved = _resolve_window_position(self.window_position, self.width, self.height)
                if resolved is not None:
                    x, y = resolved
            cv2.moveWindow(rgb_win, int(x), int(y))
            self._rgb_window_xy = (x, y)

            self._positioned_windows.add(rgb_win)

        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        cv2.imshow(rgb_win, bgr)

        if depth is not None:
            depth_win = f"{self.camera_name} - Depth"
            if depth_win not in self._positioned_windows:
                cv2.namedWindow(depth_win, cv2.WINDOW_AUTOSIZE)
                # Place it just to the right of the RGB window instead
                # of stacked on top of it.
                base_x, base_y = getattr(self, "_rgb_window_xy", (50, 50))
                cv2.moveWindow(depth_win, int(base_x) + self.width + 40, int(base_y))
                self._positioned_windows.add(depth_win)

            d = np.clip(depth, 0, max_depth)
            d_norm = (d / max_depth * 255).astype(np.uint8)
            d_color = cv2.applyColorMap(d_norm, cv2.COLORMAP_JET)
            cv2.imshow(f"{self.camera_name} - Depth", d_color)

        # waitKey(1) pumps OpenCV's window event loop; without it the
        # window never repaints or responds. The 1 is a 1ms poll, not
        # a meaningful delay -- it does not throttle your control loop.
        cv2.waitKey(1)

    def close_windows(self):
        """Close any OpenCV windows opened by show()."""
        import cv2
        cv2.destroyWindow(f"{self.camera_name} - RGB")
        try:
            cv2.destroyWindow(f"{self.camera_name} - Depth")
        except cv2.error:
            pass  # depth window was never opened

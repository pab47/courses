"""
Model-independent MuJoCo + GLFW viewer harness.

Everything here is generic: window/context setup, mouse-driven camera
control, keyboard reset, keyframe-aware reset, and the render loop.
Nothing in this file knows about a specific robot, body name, or
control law -- that all lives in the model-specific main script, which
supplies a `controller` callback (installed as MuJoCo's control
callback) and an optional `on_step` callback (called once per rendered
frame, e.g. for logging).
"""

import mujoco as mj
from mujoco.glfw import glfw
import numpy as np


class MujocoViewer:

    def __init__(
        self,
        xml_path,
        width=900,
        height=600,
        title="MuJoCo Viewer",
        reset_keyframe=None,
        maxgeom=10000,
    ):
        """
        xml_path: path to the scene MJCF to load.
        reset_keyframe: name of a <key> in the model to reset to
            (e.g. "start"). If None, reset falls back to MuJoCo's
            default qpos0 reset.
        """

        self.model = mj.MjModel.from_xml_path(xml_path)
        self.data = mj.MjData(self.model)

        self._reset_keyid = None
        if reset_keyframe is not None:
            self._reset_keyid = mj.mj_name2id(
                self.model, mj.mjtObj.mjOBJ_KEY, reset_keyframe
            )
            if self._reset_keyid < 0:
                raise ValueError(
                    f"Keyframe '{reset_keyframe}' not found in model "
                    f"loaded from {xml_path}"
                )

        self.cam = mj.MjvCamera()
        self.opt = mj.MjvOption()
        mj.mjv_defaultCamera(self.cam)
        mj.mjv_defaultOption(self.opt)

        self.print_camera_config = False

        # mouse state, for camera drag/zoom
        self._button_left = False
        self._button_middle = False
        self._button_right = False
        self._lastx = 0
        self._lasty = 0

        glfw.init()
        self.window = glfw.create_window(width, height, title, None, None)
        glfw.make_context_current(self.window)
        glfw.swap_interval(1)

        self.scene = mj.MjvScene(self.model, maxgeom=maxgeom)
        self.context = mj.MjrContext(
            self.model, mj.mjtFontScale.mjFONTSCALE_150.value
        )

        glfw.set_key_callback(self.window, self._keyboard)
        glfw.set_cursor_pos_callback(self.window, self._mouse_move)
        glfw.set_mouse_button_callback(self.window, self._mouse_button)
        glfw.set_scroll_callback(self.window, self._scroll)

        self.reset()

    # ------------------------------------------------------------
    # State control
    # ------------------------------------------------------------

    def reset(self):
        """Reset to the configured keyframe, or to qpos0 if none was given."""
        if self._reset_keyid is not None:
            mj.mj_resetDataKeyframe(self.model, self.data, self._reset_keyid)
        else:
            mj.mj_resetData(self.model, self.data)
        mj.mj_forward(self.model, self.data)

    def set_camera(self, azimuth=None, elevation=None, distance=None, lookat=None):
        if azimuth is not None:
            self.cam.azimuth = azimuth
        if elevation is not None:
            self.cam.elevation = elevation
        if distance is not None:
            self.cam.distance = distance
        if lookat is not None:
            self.cam.lookat = np.array(lookat, dtype=float)

    # ------------------------------------------------------------
    # GLFW callbacks
    # ------------------------------------------------------------

    def _keyboard(self, window, key, scancode, act, mods):
        if act == glfw.PRESS and key == glfw.KEY_BACKSPACE:
            self.reset()

    def _mouse_button(self, window, button, act, mods):
        self._button_left = (
            glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS
        )
        self._button_middle = (
            glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS
        )
        self._button_right = (
            glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS
        )
        glfw.get_cursor_pos(window)

    def _mouse_move(self, window, xpos, ypos):
        dx = xpos - self._lastx
        dy = ypos - self._lasty
        self._lastx = xpos
        self._lasty = ypos

        if not (self._button_left or self._button_middle or self._button_right):
            return

        width, height = glfw.get_window_size(window)

        mod_shift = (
            glfw.get_key(window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
            or glfw.get_key(window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
        )

        if self._button_right:
            action = (
                mj.mjtMouse.mjMOUSE_MOVE_H if mod_shift else mj.mjtMouse.mjMOUSE_MOVE_V
            )
        elif self._button_left:
            action = (
                mj.mjtMouse.mjMOUSE_ROTATE_H
                if mod_shift
                else mj.mjtMouse.mjMOUSE_ROTATE_V
            )
        else:
            action = mj.mjtMouse.mjMOUSE_ZOOM

        mj.mjv_moveCamera(
            self.model, action, dx / height, dy / height, self.scene, self.cam
        )

    def _scroll(self, window, xoffset, yoffset):
        mj.mjv_moveCamera(
            self.model,
            mj.mjtMouse.mjMOUSE_ZOOM,
            0.0,
            -0.05 * yoffset,
            self.scene,
            self.cam,
        )

    # ------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------

    def run(self, controller=None, on_step=None, sim_end=None, init=None,
            explicit_control=True):
        """
        controller(model, data): computes and applies control for the
            current state (e.g. writing data.ctrl or data.qfrc_applied).
        on_step(model, data): called once per rendered frame, after the
            physics steps for that frame (e.g. for logging/printing).
        sim_end: stop the loop once data.time >= sim_end. None runs
            until the window is closed.
        init(model, data): called once before the loop starts.
        explicit_control: if True (default), controller is called
            explicitly once per mj_step, and that control is held fixed
            through mj_step's internal integration -- required if your
            controller is non-smooth (branches, thresholds, switching
            logic), since MuJoCo's higher-order integrators (e.g. RK4)
            evaluate the control callback at several intermediate
            sub-states per step, and a non-smooth controller "jumping"
            between those evaluations corrupts the integrator's error
            cancellation. If False, controller is installed via
            mj.set_mjcb_control instead, so MuJoCo calls it internally
            at every integrator sub-stage -- only use this if your
            controller is smooth (e.g. a fixed linear feedback law).
        """

        if init is not None:
            init(self.model, self.data)

        # Only one of these should be live at a time -- always clear the
        # global callback first, since it persists across models/instances
        # until explicitly reset.
        mj.set_mjcb_control(None)

        if controller is not None and not explicit_control:
            mj.set_mjcb_control(controller)

        while not glfw.window_should_close(self.window):
            time_prev = self.data.time

            while (self.data.time - time_prev) < 1.0 / 60.0:
                if controller is not None and explicit_control:
                    controller(self.model, self.data)
                mj.mj_step(self.model, self.data)

            if on_step is not None:
                on_step(self.model, self.data)

            if sim_end is not None and self.data.time >= sim_end:
                break

            viewport_width, viewport_height = glfw.get_framebuffer_size(self.window)
            viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)

            if self.print_camera_config:
                print(
                    'cam.azimuth =', self.cam.azimuth, ';',
                    'cam.elevation =', self.cam.elevation, ';',
                    'cam.distance = ', self.cam.distance,
                )
                print(
                    'cam.lookat =np.array([', self.cam.lookat[0], ',',
                    self.cam.lookat[1], ',', self.cam.lookat[2], '])',
                )

            mj.mjv_updateScene(
                self.model,
                self.data,
                self.opt,
                None,
                self.cam,
                mj.mjtCatBit.mjCAT_ALL.value,
                self.scene,
            )
            mj.mjr_render(viewport, self.scene, self.context)

            glfw.swap_buffers(self.window)
            glfw.poll_events()

        glfw.terminate()
"""
2D LIDAR sensor simulated via MuJoCo's batched raycasting (mj_multiRay),
instead of a fixed set of <rangefinder> sites baked into the XML.

Why not a pile of <rangefinder> sensors:
  - Each rangefinder needs its own site at a fixed orientation in the
    XML, so beam count and field of view are baked into the model.
    Changing resolution means editing/regenerating XML.
  - N separate sensors means N separate readouts to collect and manage
    every step (data.sensordata slicing), rather than one array.

mj_multiRay casts many rays from one origin in a single call, and the
beam count / FOV / range are just constructor arguments here -- no XML
changes needed to add rays or change resolution. This is the same
approach MuJoCo's own raycasting-based sensor examples use to emulate
spinning LIDARs.

This module only depends on a site name (the sensor's mount point/
frame) and doesn't know anything about a specific robot -- reusable
across models, same spirit as mujoco_viewer.py.

get_data()/show() give this the same surface as lidar_sdk.LidarSDK (the
real robot's LIDAR SDK): field_of_view_degrees / range_to_see_in_meters
constructor args (overridable per get_data() call), a LidarPoints
result (x_data, y_data, angle_data -- x = forward, y = left, angle in
degrees, 0 = straight ahead, positive = counterclockwise/left), and the
same live top-down "north-up" matplotlib plot with a shaded wedge for
the field of view/range that was swept. scan()/scan_points_world() and
the original show(dist) OpenCV "radar" view are unchanged, so existing
callers (e.g. main_omnidrive.py) keep working.

One real difference from hardware: the physical LIDAR always casts a
full 360 degrees and get_data() can request any narrower window on
demand; this sensor only casts the field of view / range it was
constructed with (mj_multiRay's beams and cutoff are fixed at
construction), so get_data()'s field_of_view_degrees/range_to_see_in_meters
can narrow that window per call but not widen it. Construct with the
widest field of view/range you'll ever want if you plan to vary it.
"""

from dataclasses import dataclass, field
from typing import List

import numpy as np
import mujoco as mj


@dataclass
class LidarPoints:
    """
    Detected LiDAR points, in the robot's own frame -- same shape as
    lidar_sdk.LidarPoints.

    x_data: meters ahead of the robot, one entry per detected point
    y_data: meters to the left (positive) / right (negative), same order
    angle_data: degrees, 0 = straight ahead, positive = counterclockwise
        (left), same order
    """

    x_data: List[float] = field(default_factory=list)
    y_data: List[float] = field(default_factory=list)
    angle_data: List[float] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.x_data)


_SCREEN_SIZE = None


def _get_screen_size():
    """
    Best-effort screen size lookup, in pixels. Falls back to a
    reasonable default (1920x1080) if it can't be determined.

    Deliberately does NOT use tkinter for this: instantiating
    tkinter.Tk() just to read screen dimensions has been observed to
    hard-crash the whole process on some macOS/Tk combinations (an
    uncatchable native NSException -- "-[NSApplication macOSVersion]:
    unrecognized selector" -- which aborts the process before Python's
    own exception handling ever runs). Since that failure mode can't be
    caught, tkinter is avoided entirely here rather than attempted and
    guarded with try/except.
    """

    global _SCREEN_SIZE

    if _SCREEN_SIZE is None:
        _SCREEN_SIZE = (1920, 1080)  # safe default if detection fails

        try:
            import platform

            if platform.system() == "Darwin":
                import subprocess

                result = subprocess.run(
                    [
                        "osascript", "-e",
                        'tell application "Finder" to get bounds of window of desktop',
                    ],
                    capture_output=True, text=True, timeout=2,
                )
                if result.returncode == 0:
                    parts = [int(p.strip()) for p in result.stdout.split(",")]
                    if len(parts) == 4:
                        _SCREEN_SIZE = (parts[2], parts[3])
        except Exception:
            pass  # keep the (1920, 1080) default

    return _SCREEN_SIZE


def _ensure_safe_matplotlib_backend():
    """
    Force a native macOS backend ("MacOSX", built into matplotlib, no
    Tcl/Tk involved) before the first figure is created, so matplotlib
    can never fall back to its TkAgg backend here.

    Why: matplotlib.pyplot.subplots() with the TkAgg backend creates a
    Tk root window under the hood, same as tkinter.Tk() -- on some
    Tk/macOS combinations that hard-crashes the whole process with an
    uncatchable native NSException ("-[NSApplication macOSVersion]:
    unrecognized selector"), the same crash _get_screen_size() avoids
    by not using tkinter at all. Which backend matplotlib auto-selects
    can vary run to run (depending on what's importable/available at
    the time), which is why this can appear intermittently rather than
    every run. Must run before matplotlib.pyplot is first imported --
    switching backends after a figure already exists doesn't reliably
    undo this.
    """
    try:
        import platform

        if platform.system() == "Darwin":
            import matplotlib

            if matplotlib.get_backend().lower() != "macosx":
                matplotlib.use("MacOSX")
    except Exception:
        pass  # worst case, matplotlib falls back to its own default


def _resolve_window_position(position, fig_width_px, fig_height_px):
    """
    Resolve a window position into (x, y) pixel coordinates.

    position can be an explicit (x, y) pixel tuple, or one of the strings
    "top-left", "top-right", "bottom-left", "bottom-right".
    """

    if position is None:
        return None

    if isinstance(position, str):
        screen_width, screen_height = _get_screen_size()
        margin = 30


        corners = {
            "top-left": (margin, margin),
            "top-right": (screen_width - fig_width_px - margin, margin),
            "bottom-left": (margin, screen_height - fig_height_px - margin),
            "bottom-right": (
                screen_width - fig_width_px - margin,
                screen_height - fig_height_px - margin,
            ),
        }

        if position not in corners:
            raise ValueError(
                f"window_position string must be one of {list(corners)}, "
                f"got {position!r}"
            )

        return corners[position]

    # Assume an explicit (x, y) pixel tuple.
    return position


def _move_figure_window(fig, x, y):
    """Move a matplotlib figure window to a screen position, if the
    current backend supports it (MacOSX, TkAgg, Qt, and WX are
    covered; other backends silently do nothing)."""

    try:
        import matplotlib.pyplot as plt

        manager = fig.canvas.manager
        backend = plt.get_backend()

        if backend.lower() == "macosx":
            manager.window.setFrameOrigin_((int(x), int(y)))
        elif backend == "TkAgg":
            manager.window.wm_geometry(f"+{int(x)}+{int(y)}")
        elif backend in ("QtAgg", "Qt5Agg", "Qt4Agg"):
            manager.window.move(int(x), int(y))
        elif backend == "WXAgg":
            manager.window.SetPosition((int(x), int(y)))
    except Exception:
        pass  # Window positioning isn't supported by every backend/setup


class Lidar2D:
    """
    Planar (2D) LIDAR: all beams lie in the mounting site's local
    x/y plane, sweeping around the site's local z-axis ("up").

    Parameters
    ----------
    model : mj.MjModel
    site_name : str
        Name of the site the LIDAR is mounted at (e.g. "lidar_frame").
        Its position and orientation each step come from
        data.site_xpos / data.site_xmat.
    num_beams : int
        Number of rays per scan.
    field_of_view_degrees : float
        Field of view, in degrees. Use 360 for a full rotating scan.
        This is also the default used by get_data()/show() when called
        with no arguments (like lidar_sdk.LidarSDK).
    range_to_see_in_meters : float
        Rays beyond this distance are ignored (mj_multiRay's cutoff);
        misses report a distance of range_to_see_in_meters. Also the
        default range used by get_data()/show().
    exclude_body : str or int, optional
        Body name or id to exclude from hits (typically the robot's
        own chassis, so the LIDAR doesn't detect itself).
    window_position : optional
        Where get_data()'s matplotlib plot window should appear -- an
        explicit (x, y) pixel tuple, or one of "top-left", "top-right",
        "bottom-left", "bottom-right". None leaves it to the window
        manager.
    data : mj.MjData, optional
        Bind a live MjData up front so get_data()/show() can be called
        with no arguments, same as the hardware SDK -- MuJoCo mutates
        MjData's arrays in place each mj_step, so a reference taken
        once stays current. Can also be set later via set_data(), or
        passed per-call via get_data(data=...). scan()/scan_points_world()
        are unaffected -- they always take data explicitly.
    fov, max_range : deprecated
        Old names for field_of_view_degrees (in radians) and
        range_to_see_in_meters. Still accepted for existing callers.
    """

    def __init__(
        self,
        model,
        site_name,
        num_beams=360,
        field_of_view_degrees=None,
        range_to_see_in_meters=None,
        exclude_body=None,
        window_position=None,
        data=None,
        fov=None,
        max_range=None,
    ):
        if field_of_view_degrees is None:
            field_of_view_degrees = np.degrees(fov) if fov is not None else 360.0
        if range_to_see_in_meters is None:
            range_to_see_in_meters = max_range if max_range is not None else 5.0

        self.model = model
        self.siteid = mj.mj_name2id(model, mj.mjtObj.mjOBJ_SITE, site_name)
        if self.siteid < 0:
            raise ValueError(f"Site '{site_name}' not found in model")

        self.num_beams = num_beams

        # Hardware-SDK-facing defaults, used by get_data()/show() when
        # called with no arguments.
        self.field_of_view_degrees = field_of_view_degrees
        self.range_to_see_in_meters = range_to_see_in_meters
        self.window_position = window_position
        self._data = data

        # Raycasting units (radians / meters).
        self.fov = np.radians(field_of_view_degrees)
        self.max_range = range_to_see_in_meters

        if isinstance(exclude_body, str):
            bodyid = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, exclude_body)
            if bodyid < 0:
                raise ValueError(f"Body '{exclude_body}' not found in model")
            exclude_body = bodyid
        self.bodyexclude = -1 if exclude_body is None else exclude_body

        # A full 2*pi sweep should not repeat the same angle at both
        # ends (endpoint=False); a partial FOV should include both
        # edges (endpoint=True).
        full_circle = abs(self.fov - 2 * np.pi) < 1e-9
        self.angles = np.linspace(
            -self.fov / 2.0, self.fov / 2.0, num_beams, endpoint=not full_circle
        )

        # Precompute ray directions in the site's LOCAL frame; these get
        # rotated into world frame each scan via the site's current
        # orientation, so the sweep follows the robot's heading.
        local_dirs = np.zeros((num_beams, 3))
        local_dirs[:, 0] = np.cos(self.angles)
        local_dirs[:, 1] = np.sin(self.angles)
        self._local_dirs = local_dirs

        # Scratch buffers for mj_multiRay (reused across scans to avoid
        # reallocating every step).
        self._geomid = np.zeros(num_beams, dtype=np.int32)
        self._dist = np.zeros(num_beams, dtype=np.float64)

        # get_data()/show() cache.
        self._last_points = LidarPoints()
        self._last_dist = None

        # Lazily created the first time show() (no-args form) is called.
        self._fig = None
        self._ax = None

    def set_data(self, data):
        """Bind (or rebind) the live MjData used by get_data()/show()."""
        self._data = data

    def scan(self, data):
        """
        Cast the LIDAR's rays against the current state in `data`.

        Returns
        -------
        dist : (num_beams,) float64 array
            Range to the nearest hit per beam, in meters. Beams with no
            hit within max_range report max_range (not -1), so this
            array is always usable directly as a range image.
        geomid : (num_beams,) int32 array
            Geom id hit by each beam, or -1 for no hit.
        angles : (num_beams,) float64 array
            The beam angles (radians), in the site's local frame,
            matching dist/geomid index-for-index.
        """

        site_pos = data.site_xpos[self.siteid]
        site_mat = data.site_xmat[self.siteid].reshape(3, 3)

        world_dirs = self._local_dirs @ site_mat.T
        vec = np.ascontiguousarray(world_dirs.reshape(-1))
        pnt = np.ascontiguousarray(site_pos.astype(np.float64))

        kwargs = dict(
            m=self.model,
            d=data,
            pnt=pnt,
            vec=vec,
            geomgroup=None,
            flg_static=1,
            bodyexclude=self.bodyexclude,
            geomid=self._geomid,
            dist=self._dist,
            nray=self.num_beams,
            cutoff=self.max_range,
        )

        # mj_multiRay's signature differs across mujoco builds: some
        # require a `normal` kwarg (even if just None), others don't
        # accept it at all. Detected lazily on first call and cached
        # as an instance attribute so later calls skip the try/except.
        wants_normal = getattr(self, "_wants_normal", None)

        if wants_normal is None:
            try:
                mj.mj_multiRay(**kwargs, normal=None)
                self._wants_normal = True
            except TypeError:
                mj.mj_multiRay(**kwargs)
                self._wants_normal = False
        elif wants_normal:
            mj.mj_multiRay(**kwargs, normal=None)
        else:
            mj.mj_multiRay(**kwargs)

        # mj_multiRay reports -1 distance for misses; clamp those to
        # max_range so the output is a well-formed range array.
        dist = np.where(self._dist < 0, self.max_range, self._dist)

        return dist, self._geomid.copy(), self.angles


    def scan_points_world(self, data):
        """
        Same as scan(), but also returns each beam's hit point in world
        (x, y, z) coordinates -- useful for occupancy-grid/mapping code
        that needs points in a fixed global frame rather than range+angle
        relative to the robot.

        Returns
        -------
        dist, geomid, angles : same as scan()
        points_world : (num_beams, 3) float64 array
            World-frame coordinates of each beam's endpoint (hit point,
            or the max_range point along the ray if it missed).
        """
        dist, geomid, angles = self.scan(data)

        site_pos = data.site_xpos[self.siteid]
        site_mat = data.site_xmat[self.siteid].reshape(3, 3)
        world_dirs = self._local_dirs @ site_mat.T

        points_world = site_pos + world_dirs * dist[:, None]

        return dist, geomid, angles, points_world

    def get_data(self, field_of_view_degrees=None, range_to_see_in_meters=None, data=None):
        """
        Sweep this sensor's field of view and return every detected
        point as a LidarPoints structure (x_data, y_data, angle_data),
        in the robot's own frame (x = forward, y = left, angle in
        degrees, 0 = straight ahead, positive = counterclockwise/left)
        -- same convention and shape as lidar_sdk.LidarSDK.get_data(),
        so code written against the real sensor works against this one.

        field_of_view_degrees / range_to_see_in_meters narrow the
        window reported from what this sensor actually casts (see the
        class docstring for why it can't widen beyond that). Omit
        either to use this instance's defaults.

        data defaults to whatever was bound via the constructor's
        `data` argument or set_data(); pass it explicitly if you
        haven't bound one.

        The result is cached on this instance so a subsequent show()
        call (with no arguments) redraws it without another get_data()
        call.
        """
        if data is None:
            data = self._data
        if data is None:
            raise ValueError(
                "No MjData bound -- pass data=... to get_data(), or call "
                "set_data(data) / construct this Lidar2D with data=... first."
            )

        if field_of_view_degrees is None:
            field_of_view_degrees = self.field_of_view_degrees
        if range_to_see_in_meters is None:
            range_to_see_in_meters = self.range_to_see_in_meters

        dist, geomid, angles = self.scan(data)

        # "No return" beams (nothing detected within this sensor's own
        # max range) are excluded, same as a real LiDAR only reporting
        # actual hits.
        hit_mask = dist < (self.max_range - 1e-6)
        half_fov = np.radians(field_of_view_degrees) / 2.0
        in_fov = np.abs(angles) <= half_fov
        in_range = dist <= range_to_see_in_meters
        keep = hit_mask & in_fov & in_range

        points = LidarPoints(
            x_data=(dist[keep] * np.cos(angles[keep])).tolist(),
            y_data=(dist[keep] * np.sin(angles[keep])).tolist(),
            angle_data=np.degrees(angles[keep]).tolist(),
        )

        self._last_points = points
        self._last_dist = dist
        return points

    def show(self, dist=None, size=400, max_range=None, ring_step=1.0):
        """
        Visualize the most recent scan. Two styles, depending on how
        it's called:

        - show(dist): legacy top-down "radar" view, drawn in an OpenCV
          window (unchanged -- see _show_radar_cv2 for the docstring).
          `dist` is the array returned by scan(); kept for existing
          callers like main_omnidrive.py.
        - show(): (no arguments) live top-down, north-up matplotlib
          plot of the most recent get_data() result, with a shaded
          wedge showing the field of view/range that was swept -- same
          look as lidar_sdk.LidarSDK.show(). Call this after get_data().
        """
        if dist is not None:
            self._show_radar_cv2(dist, size=size, max_range=max_range, ring_step=ring_step)
        else:
            self._show_topdown_matplotlib()

    def _show_radar_cv2(self, dist, size=400, max_range=None, ring_step=1.0):
        """
        Top-down "radar" visualization of the most recent scan, drawn
        in an OpenCV window -- the LIDAR equivalent of RGBDCamera.show().

        Robot-centric, egocentric view: the robot sits at the center
        of the canvas with local +x (forward) pointing up and local
        +y (left) pointing left, same convention as a car's nav
        display. Call this once per frame from your control loop,
        same as RGBDCamera.show().

        Parameters
        ----------
        dist : (num_beams,) array, as returned by scan()
        size : int
            Canvas size in pixels (square window).
        max_range : float, optional
            Visualization range -- defaults to self.max_range. Only
            affects the display scale, not the underlying data.
        ring_step : float
            Spacing (in meters) between the reference range rings.
        """
        import cv2  # local import, same reasoning as RGBDCamera.show()

        max_range = self.max_range if max_range is None else max_range
        canvas = np.zeros((size, size, 3), dtype=np.uint8)
        cx, cy = size // 2, size // 2
        scale = (size / 2 - 20) / max_range  # pixels per meter, with margin

        # Range rings + labels, every ring_step meters
        ring = ring_step
        while ring <= max_range:
            r_px = int(ring * scale)
            cv2.circle(canvas, (cx, cy), r_px, (60, 60, 60), 1)
            cv2.putText(canvas, f"{ring:.0f}m", (cx + 4, cy - r_px + 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (100, 100, 100), 1)
            ring += ring_step

        # Robot heading axes (forward = up, left = left)
        cv2.line(canvas, (cx, cy), (cx, cy - 15), (0, 0, 255), 2)  # forward, red

        # Hit points only -- beams that reported max_range are "no
        # return" (nothing detected within range) rather than a real
        # detection at that exact distance, so they're skipped here,
        # same spirit as a real LIDAR display only plotting returns.
        hit_mask = dist < (max_range - 1e-6)
        px = dist[hit_mask] * np.cos(self.angles[hit_mask])
        py = dist[hit_mask] * np.sin(self.angles[hit_mask])
        cols = (cx - py * scale).astype(int)
        rows = (cy - px * scale).astype(int)

        in_bounds = (cols >= 0) & (cols < size) & (rows >= 0) & (rows < size)
        for col, row in zip(cols[in_bounds], rows[in_bounds]):
            cv2.circle(canvas, (col, row), 2, (0, 255, 0), -1)

        # Robot marker on top of the points, drawn last
        cv2.circle(canvas, (cx, cy), 5, (255, 255, 0), -1)

        win = "LIDAR - top-down"
        if not hasattr(self, "_window_positioned"):
            cv2.namedWindow(win, cv2.WINDOW_AUTOSIZE)
            cv2.moveWindow(win, 50, 50 + 240 + 40)  # below the camera windows
            self._window_positioned = True

        cv2.imshow(win, canvas)
        cv2.waitKey(1)

    def _show_topdown_matplotlib(self):
        """
        Draw/update a live top-down, north-up plot of the most recent
        get_data() result -- ported from lidar_sdk.LidarSDK.show().

        - The robot is fixed at (0, 0), facing +y (north / up the page).
        - Both axes run from -range_to_see_in_meters to
          +range_to_see_in_meters (using self.range_to_see_in_meters).
        - A shaded wedge shows the field_of_view cone that was swept
          (using self.field_of_view_degrees).

        Non-blocking, meant to be called once per loop iteration after
        get_data().

        Requires matplotlib:
            pip install matplotlib --break-system-packages
        """
        if self._fig is None:
            _ensure_safe_matplotlib_backend()

        import matplotlib.pyplot as plt
        from matplotlib.patches import Wedge

        if self._fig is None or not plt.fignum_exists(self._fig.number):
            plt.ion()
            self._fig, self._ax = plt.subplots(figsize=(4, 4))

            if self.window_position is not None:
                fig_width_px = self._fig.get_size_inches()[0] * self._fig.dpi
                fig_height_px = self._fig.get_size_inches()[1] * self._fig.dpi
                resolved = _resolve_window_position(
                    self.window_position, fig_width_px, fig_height_px
                )
                if resolved is not None:
                    _move_figure_window(self._fig, *resolved)

        points = self._last_points
        half_fov = self.field_of_view_degrees / 2.0
        range_to_see_in_meters = self.range_to_see_in_meters

        # Rotate from the robot's own frame (x = forward, y = left) into
        # the plot's frame, where "forward" points up the page (+y /
        # north) and "left" points to the page's left.
        plot_x = [-y for y in points.y_data]
        plot_y = list(points.x_data)

        ax = self._ax
        ax.clear()

        cone = Wedge(
            (0, 0),
            range_to_see_in_meters,
            90 - half_fov,
            90 + half_fov,
            alpha=0.15,
            color="tab:blue",
        )
        ax.add_patch(cone)

        ax.scatter(plot_x, plot_y, s=10, c="tab:red", zorder=4)

        # Robot marker at the origin, pointing north (up the page).
        ax.scatter([0], [0], c="black", marker="^", s=120, zorder=5)

        ax.set_xlim(-range_to_see_in_meters, range_to_see_in_meters)
        ax.set_ylim(-range_to_see_in_meters, range_to_see_in_meters)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("meters (robot's left / right)")
        ax.set_ylabel("meters (robot's forward / back)")
        ax.set_title(
            f"LiDAR -- {len(points)} points, "
            f"fov={self.field_of_view_degrees:.0f} deg, "
            f"range={range_to_see_in_meters:.1f} m"
        )
        ax.grid(True)

        plt.pause(0.001)

    def close_window(self):
        """Close the OpenCV window opened by show(dist)."""
        import cv2
        cv2.destroyWindow("LIDAR - top-down")

    def close(self):
        """Close the matplotlib window opened by show(), if any."""
        if self._fig is not None:
            import matplotlib.pyplot as plt
            plt.close(self._fig)

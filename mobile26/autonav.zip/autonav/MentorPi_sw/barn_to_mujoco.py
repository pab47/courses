import os
import numpy as np
import matplotlib.pyplot as plt

# Modified from James Bittler's file.
#
# v2: the synthetic boundary (previously ~2*30 + 4*n small cylinder cells)
# is now 4 large box geoms, one per side. Fewer geoms means fewer
# broad-phase collision pairs, and MuJoCo's box-box collision routine
# (SAT) is cheaper per-pair than cylinder-cylinder -- so this boundary
# is both fewer AND individually cheaper to check against every step.
# The interior BARN obstacles (from the actual grid data) are unchanged:
# still one cylinder per occupied cell.

verbose = 1
visualize = 1
write_xml = 1

# ============================================================
# BARN PARAMETERS
# ============================================================

dir_str = "/Users/pranav/Documents/python"  # manually set directory
                                             # where the folder "BARN_dataset" is located

BARN_num = 5    # Environment ID [0,299]
BARN_scale = 0.15

# ============================================================
# MUJOCO PARAMETERS
# ============================================================

cylinder_height = 0.16   # obstacle cylinder height, in meters (160 mm)
# mjcf_out_dir = dir_str + "/BARN_dataset/mujoco_files"
# mjcf_out_path = mjcf_out_dir + f"/barn_{BARN_num}.xml"
# scene_out_path = mjcf_out_dir + f"/scene_{BARN_num}.xml"

script_dir = os.path.dirname(os.path.abspath(__file__))
script_dir = script_dir + "/BARN"
mjcf_out_dir = script_dir 
mjcf_out_path = script_dir + f"/barn_{BARN_num}.xml"
scene_out_path = script_dir + f"/scene_{BARN_num}.xml"

# Name of the robot MJCF file (expected to already sit in mjcf_out_dir,
# with its own floor/ground-plane geom removed -- the floor now comes
# from the BARN environment file instead).
robot_file_name = "../robot/omnidrive.xml"

# Chassis height above the floor for the free joint, in meters
# (matches the "pos" the chassis body uses in omnidrive.xml).
chassis_z = 0.056

# ============================================================
# LOAD WORLD
# ============================================================

world_file = (
    dir_str +
    f"/BARN_dataset/grid_files/grid_{BARN_num}.npy"
)

barn_world = BARN_scale * np.load(world_file)

# ============================================================
# LOAD REFERENCE PATH
# ============================================================

path_file = (
    dir_str +
    f"/BARN_dataset/path_files/path_{BARN_num}.npy"
)

barn_path = BARN_scale * np.load(path_file).T

# ============================================================
# ENVIRONMENT DIMENSIONS
# ============================================================

# x_origin = BARN_scale * 15
# y_origin = BARN_scale * 15

x_span = BARN_scale * 30
y_span = BARN_scale * 30

# ============================================================
# START / GOAL
# ============================================================

start_xy = barn_path[:, 0]
goal_xy = barn_path[:, -1]

# ============================================================
# INTERIOR OBSTACLES (boundary is now handled separately as 4 boxes)
# ============================================================

n = 6   # padding, in cells, between the grid edge and the boundary walls

# Original BARN obstacles (cell coordinates) -- boundary rows/columns
# are no longer folded into this array, see boundary_wall_specs() below.
obstacle_xy = np.argwhere(barn_world != 0)

# Convert cell centers to metric coordinates
obstacle_xy = BARN_scale * (obstacle_xy + 0.5)

# Radius of each obstacle
obstacle_r = (
    0.5 * BARN_scale *
    np.ones(obstacle_xy.shape[0])
)

if (verbose > 0):
    print("World shape:", barn_world.shape)
    print("Number of interior obstacles:", obstacle_xy.shape[0])
    print("Start:", start_xy)
    print("Goal:", goal_xy)

# ============================================================
# MUJOCO XML EXPORT
# ============================================================


def boundary_wall_specs(x_span, y_span, n, BARN_scale, cylinder_height):
    """
    Compute the 4 boundary box geoms (south, north, west, east) that
    enclose the environment, replacing the old per-cell cylinder
    boundary. Each spec is (name, half_x, half_y, half_z, x, y, z).

    The walls sit `n` cells outside the grid edge (same padding as the
    original boundary) and are one cell thick. West/east span the full
    padded height so the 4 boxes form a closed rectangle with no gaps
    at the corners.
    """

    margin = (n + 1) * BARN_scale
    wall_thickness = BARN_scale
    half_h = cylinder_height / 2.0

    outer_x_min = -margin
    outer_x_max = x_span + margin
    outer_y_min = -margin
    outer_y_max = y_span + margin

    half_x_full = (outer_x_max - outer_x_min) / 2.0
    half_y_full = (outer_y_max - outer_y_min) / 2.0

    specs = [
        (
            "wall_south",
            half_x_full, wall_thickness / 2.0, half_h,
            x_span / 2.0, outer_y_min + wall_thickness / 2.0, half_h,
        ),
        (
            "wall_north",
            half_x_full, wall_thickness / 2.0, half_h,
            x_span / 2.0, outer_y_max - wall_thickness / 2.0, half_h,
        ),
        (
            "wall_west",
            wall_thickness / 2.0, half_y_full, half_h,
            outer_x_min + wall_thickness / 2.0, y_span / 2.0, half_h,
        ),
        (
            "wall_east",
            wall_thickness / 2.0, half_y_full, half_h,
            outer_x_max - wall_thickness / 2.0, y_span / 2.0, half_h,
        ),
    ]

    return specs


def obstacles_to_mjcf(
    obstacle_xy,
    obstacle_r,
    x_span,
    y_span,
    n,
    BARN_scale,
    start_xy,
    goal_xy,
    cylinder_height=0.16,
    out_path="barn_env.xml",
    model_name="barn_env",
):
    """
    Write out a MuJoCo MJCF model where interior BARN obstacles are
    fixed cylinders and the boundary is 4 fixed box walls, all sitting
    on a ground plane. Start/goal are added as visual-only sites.
    """

    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    half_h = cylinder_height / 2.0

    lines = []
    lines.append(f'<mujoco model="{model_name}">')
    lines.append('  <compiler angle="radian" coordinate="local"/>')
    lines.append('  <option gravity="0 0 -9.81"/>')
    lines.append('  <asset>')
    lines.append(
        '    <texture type="skybox" builtin="gradient" '
        'rgb1="0.3 0.5 0.7" rgb2="0 0 0" width="512" height="512"/>'
    )
    lines.append(
        '    <texture name="grid" type="2d" builtin="checker" '
        'rgb1="0.1 0.2 0.3" rgb2="0.2 0.3 0.4" width="300" height="300"/>'
    )
    lines.append(
        '    <material name="grid_mat" texture="grid" '
        'texrepeat="10 10" reflectance="0.2"/>'
    )
    lines.append('  </asset>')
    lines.append('  <worldbody>')
    lines.append(
        '    <light directional="true" diffuse="0.8 0.8 0.8" '
        'pos="0 0 5" dir="0 0 -1"/>'
    )

    # Ground plane, centered under the environment span
    lines.append(
        f'    <geom name="floor" type="plane" '
        f'size="{x_span / 2:.4f} {y_span / 2:.4f} 0.1" '
        f'pos="{x_span / 2:.4f} {y_span / 2:.4f} 0" material="grid_mat"/>'
    )

    # Start / goal markers (visual only, no collision)
    lines.append(
        f'    <site name="start" type="sphere" size="0.05" '
        f'pos="{start_xy[0]:.4f} {start_xy[1]:.4f} 0.05" rgba="0 1 0 1"/>'
    )
    lines.append(
        f'    <site name="goal" type="sphere" size="0.05" '
        f'pos="{goal_xy[0]:.4f} {goal_xy[1]:.4f} 0.05" rgba="1 0 0 1"/>'
    )

    # Boundary: 4 box walls instead of many small boundary cylinders
    for name, hx, hy, hz, x, y, z in boundary_wall_specs(
        x_span, y_span, n, BARN_scale, cylinder_height
    ):
        lines.append(
            f'    <geom name="{name}" type="box" '
            f'size="{hx:.5f} {hy:.5f} {hz:.5f}" '
            f'pos="{x:.4f} {y:.4f} {z:.5f}" rgba="0.35 0.35 0.35 1"/>'
        )

    # Interior obstacle cylinders, resting on the floor
    for i, (obs, r) in enumerate(zip(obstacle_xy, obstacle_r)):
        x, y = obs[0], obs[1]
        lines.append(
            f'    <geom name="obstacle_{i}" type="cylinder" '
            f'size="{r:.5f} {half_h:.5f}" '
            f'pos="{x:.4f} {y:.4f} {half_h:.5f}" rgba="0.2 0.2 0.2 1"/>'
        )

    lines.append('  </worldbody>')
    lines.append('</mujoco>')

    xml_str = "\n".join(lines)
    with open(out_path, "w") as f:
        f.write(xml_str)

    if verbose > 0:
        print(
            f"Wrote MuJoCo XML to {out_path} "
            f"with {obstacle_xy.shape[0]} interior cylinders + 4 boundary "
            f"box walls (height {cylinder_height * 1000:.0f} mm)"
        )

    return out_path


def write_scene_xml(
    robot_file_name,
    env_file_name,
    start_xy,
    chassis_z=0.056,
    out_path="scene.xml",
    model_name="scene",
):
    """
    Write a scene MJCF that composes the robot (free-joint chassis) with
    the BARN environment, and places the robot at the BARN start position
    via a <keyframe>. Loading the model alone leaves qpos at qpos0 (the
    body's compiled reference pose) -- the keyframe only takes effect if
    you explicitly apply it, e.g. mj_resetDataKeyframe(model, data, 0) in
    code, or selecting it from the keyframe dropdown in the `simulate` GUI.

    Assumes the merged model's only joint is the chassis free joint
    (7 qpos values: x y z qw qx qy qz), which holds for the unmodified
    omnidrive.xml + obstacles_to_mjcf() environment (obstacles/walls/
    floor are all static geoms with no joints).
    """

    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    qpos_start = f"{start_xy[0]:.4f} {start_xy[1]:.4f} {chassis_z:.4f} 0.7071 0 0 0.7071"
    qpos_goal = f"{goal_xy[0]:.4f} {goal_xy[1]:.4f} {chassis_z:.4f} 0.7071 0 0 0.7071"
    
    lines = []
    lines.append(f'<mujoco model="{model_name}">')
    lines.append('')
    lines.append(f'    <include file="{robot_file_name}"/>')
    lines.append(f'    <include file="{env_file_name}"/>')
    lines.append('')
    lines.append('    <keyframe>')
    lines.append(f'        <key name="start" qpos="{qpos_start}"/>')
    lines.append(f'        <key name="goal" qpos="{qpos_goal}"/>')
    lines.append('    </keyframe>')
    lines.append('')
    lines.append('</mujoco>')

    xml_str = "\n".join(lines)
    with open(out_path, "w") as f:
        f.write(xml_str)

    if verbose > 0:
        print(
            f"Wrote scene MJCF to {out_path} "
            f"(includes {robot_file_name} + {env_file_name}, "
            f"robot start qpos = [{qpos_start}])"
        )

    return out_path


if write_xml > 0:
    obstacles_to_mjcf(
        obstacle_xy,
        obstacle_r,
        x_span,
        y_span,
        n,
        BARN_scale,
        start_xy,
        goal_xy,
        cylinder_height=cylinder_height,
        out_path=mjcf_out_path,
        model_name=f"barn_{BARN_num}",
    )

    write_scene_xml(
        robot_file_name=robot_file_name,
        env_file_name=os.path.basename(mjcf_out_path),
        start_xy=start_xy,
        chassis_z=chassis_z,
        out_path=scene_out_path,
        model_name=f"barn_{BARN_num}_scene",
    )

# ============================================================
# VISUALIZATION
# ============================================================

if (visualize > 0):
    fig, ax = plt.subplots(figsize=(8, 8))

    # ------------------------------------------------------------
    # Occupancy grid background
    # ------------------------------------------------------------

    ax.imshow(
        barn_world.T,
        origin='lower',
        cmap='Greys',
        extent=[0, x_span, 0, y_span],
        alpha=0.4
    )

    # ------------------------------------------------------------
    # Interior obstacles
    # ------------------------------------------------------------

    for obs in obstacle_xy:

        x = obs[0]
        y = obs[1]

        circle = plt.Circle(
            (x, y),
            obstacle_r[0],
            color='black'
        )

        ax.add_patch(circle)

    # ------------------------------------------------------------
    # Boundary walls (drawn as rectangles, matching the MJCF boxes)
    # ------------------------------------------------------------

    for name, hx, hy, hz, wx, wy, wz in boundary_wall_specs(
        x_span, y_span, n, BARN_scale, cylinder_height
    ):
        rect = plt.Rectangle(
            (wx - hx, wy - hy),
            2 * hx,
            2 * hy,
            color='dimgray'
        )
        ax.add_patch(rect)

    # ------------------------------------------------------------
    # BARN reference path
    # ------------------------------------------------------------

    ax.plot(
        barn_path[0, :],
        barn_path[1, :],
        linewidth=3,
        label='Reference Path'
    )

    # ------------------------------------------------------------
    # Start
    # ------------------------------------------------------------

    ax.plot(
        start_xy[0],
        start_xy[1],
        'go',
        markersize=12,
        label='Start'
    )

    # ------------------------------------------------------------
    # Goal
    # ------------------------------------------------------------

    ax.plot(
        goal_xy[0],
        goal_xy[1],
        'ro',
        markersize=12,
        label='Goal'
    )

    # ------------------------------------------------------------
    # Labels
    # ------------------------------------------------------------

    ax.set_title(
        f'BARN Environment {BARN_num}',
        fontsize=16
    )

    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')

    margin = (n + 1) * BARN_scale
    ax.set_xlim(-margin, x_span + margin)
    ax.set_ylim(-margin, y_span + margin)

    ax.set_aspect('equal')

    ax.grid(True)

    ax.legend()

    plt.tight_layout()
    plt.show()

#!/usr/bin/env python3

"""
Hardware-specific setup for the MentorPi robot: which SDKs to import,
how to construct/configure them, and how to enter/exit their context
managers. Everything platform-specific lives here so that control_loop()
(in test_basic.py) can stay platform-independent.

mentorpi_sw.py is the simulation counterpart -- it exposes the same
open_robot() -> (robot, lidar, camera) interface (set_velocity/stop/
get_data/show), so control_loop() doesn't need to know or care which
one it's talking to.
"""

from contextlib import contextmanager

from motion_sdk import MentorPi
from lidar_sdk import LidarSDK
from vision_sdk import VisionSDK

# Chassis type for the robot under test: "ackermann" or "mecanum"
CHASSIS_TYPE = "mecanum"


@contextmanager
def open_robot():
    """
    Opens the real robot, LIDAR, and camera; waits for the sensors to be
    ready; and yields (robot, lidar, camera) for the caller to drive.
    """
    with (
        MentorPi(chassis_type=CHASSIS_TYPE) as robot,
        LidarSDK(
            field_of_view_degrees=90.0,
            range_to_see_in_meters=3.0,
            window_position="top-left",
        ) as lidar,
        VisionSDK(window_position="bottom-right") as camera,
    ):
        # Initialize the camera and LIDAR
        lidar.wait_for_scan(timeout=5.0)
        camera.wait_until_ready(timeout=8.0)

        yield robot, lidar, camera


if __name__ == "__main__":
    from test_basic import control_loop

    with open_robot() as (robot, lidar, camera):
        control_loop(robot, lidar, camera)

#!/usr/bin/env python3

import math
import os
import threading
import time
from dataclasses import dataclass
from typing import Optional

import numpy as np
import rclpy
from cv_bridge import CvBridge
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image, PointCloud2

try:
    from sensor_msgs_py import point_cloud2
except ImportError:
    point_cloud2 = None


@dataclass
class VisionData:
    """
    RGB + depth data captured together, as returned by VisionSDK.get_data().

    rgb: H x W x 3 RGB image, or None if not yet received
    depth: H x W depth image in meters, or None if not yet received
    center_depth: depth reading (meters) at the center of the frame, or
        None if unavailable
    """

    rgb: Optional[np.ndarray] = None
    depth: Optional[np.ndarray] = None
    center_depth: Optional[float] = None


_SCREEN_SIZE = None


def _get_screen_size():
    """Best-effort screen size lookup, in pixels. Falls back to a
    reasonable default if it can't be determined."""

    global _SCREEN_SIZE

    if _SCREEN_SIZE is None:
        try:
            import tkinter

            root = tkinter.Tk()
            root.withdraw()
            _SCREEN_SIZE = (root.winfo_screenwidth(), root.winfo_screenheight())
            root.destroy()
        except Exception:
            _SCREEN_SIZE = (1920, 1080)

    return _SCREEN_SIZE


def _resolve_window_position(position, fig_width_px, fig_height_px):
    """
    Resolve a window position into (x, y) pixel coordinates.

    position can be an explicit (x, y) pixel tuple, or one of the strings
    "top-left", "top-right", "bottom-left", "bottom-right".
    """

    if position is None:
        return None

    if isinstance(position, str):
        screen_width, screen_height = _get_screen_size()
        margin = 30

        corners = {
            "top-left": (margin, margin),
            "top-right": (screen_width - fig_width_px - margin, margin),
            "bottom-left": (margin, screen_height - fig_height_px - margin),
            "bottom-right": (
                screen_width - fig_width_px - margin,
                screen_height - fig_height_px - margin,
            ),
        }

        if position not in corners:
            raise ValueError(
                f"window_position string must be one of {list(corners)}, "
                f"got {position!r}"
            )

        return corners[position]

    # Assume an explicit (x, y) pixel tuple.
    return position


def _move_figure_window(fig, x, y):
    """Move a matplotlib figure window to a screen position, if the
    current backend supports it (TkAgg, Qt, and WX are covered; other
    backends silently do nothing)."""

    try:
        import matplotlib.pyplot as plt

        manager = fig.canvas.manager
        backend = plt.get_backend()

        if backend == "TkAgg":
            manager.window.wm_geometry(f"+{int(x)}+{int(y)}")
        elif backend in ("QtAgg", "Qt5Agg", "Qt4Agg"):
            manager.window.move(int(x), int(y))
        elif backend == "WXAgg":
            manager.window.SetPosition((int(x), int(y)))
    except Exception:
        pass  # Window positioning isn't supported by every backend/setup


class VisionSDK:
    """Simple high-level ROS 2 vision SDK for MentorPi."""

    def __init__(
        self,
        rgb_topic="/ascamera/camera_publisher/rgb0/image",
        depth_topic="/ascamera/camera_publisher/depth0/image_raw",
        depth_info_topic="/ascamera/camera_publisher/depth0/camera_info",
        pointcloud_topic="/ascamera/camera_publisher/depth0/points",
        window_position=None,
    ):
        self.rgb_topic = rgb_topic
        self.depth_topic = depth_topic
        self.depth_info_topic = depth_info_topic
        self.pointcloud_topic = pointcloud_topic

        # Where to place the plot window on screen. Either an explicit
        # (x, y) pixel tuple, or one of "top-left", "top-right",
        # "bottom-left", "bottom-right". None leaves it wherever the
        # window manager puts it by default.
        self.window_position = window_position

        self._closed = False
        self._owns_ros_context = not rclpy.ok()

        if self._owns_ros_context:
            rclpy.init()

        self.node = Node(f"mentorpi_vision_sdk_{os.getpid()}")
        self.bridge = CvBridge()
        self._lock = threading.Lock()

        self._rgb_msg = None
        self._depth_msg = None
        self._depth_info_msg = None
        self._pointcloud_msg = None

        # Cached result of the last get_data() call, redrawn by show().
        self._last_data = VisionData()

        # Lazily created the first time show() is called.
        self._fig = None
        self._rgb_axis = None
        self._depth_axis = None
        self._rgb_plot = None
        self._depth_plot = None

        self.rgb_subscription = self.node.create_subscription(
            Image,
            self.rgb_topic,
            self._rgb_callback,
            qos_profile_sensor_data,
        )
        self.depth_subscription = self.node.create_subscription(
            Image,
            self.depth_topic,
            self._depth_callback,
            qos_profile_sensor_data,
        )
        self.depth_info_subscription = self.node.create_subscription(
            CameraInfo,
            self.depth_info_topic,
            self._depth_info_callback,
            qos_profile_sensor_data,
        )
        self.pointcloud_subscription = self.node.create_subscription(
            PointCloud2,
            self.pointcloud_topic,
            self._pointcloud_callback,
            qos_profile_sensor_data,
        )

        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.node)
        self._spin_thread = threading.Thread(
            target=self.executor.spin,
            daemon=True,
        )
        self._spin_thread.start()

    def _rgb_callback(self, message):
        with self._lock:
            self._rgb_msg = message

    def _depth_callback(self, message):
        with self._lock:
            self._depth_msg = message

    def _depth_info_callback(self, message):
        with self._lock:
            self._depth_info_msg = message

    def _pointcloud_callback(self, message):
        with self._lock:
            self._pointcloud_msg = message

    def wait_until_ready(self, timeout=5.0, require_pointcloud=False):
        """Wait for RGB, depth, camera-info, and optionally point-cloud data."""
        end_time = time.monotonic() + timeout

        while time.monotonic() < end_time:
            with self._lock:
                ready = (
                    self._rgb_msg is not None
                    and self._depth_msg is not None
                    and self._depth_info_msg is not None
                )
                if require_pointcloud:
                    ready = ready and self._pointcloud_msg is not None

            if ready:
                return True
            time.sleep(0.05)

        return False

    def is_ready(self):
        """Return True when RGB, depth, and camera-info data are available."""
        with self._lock:
            return (
                self._rgb_msg is not None
                and self._depth_msg is not None
                and self._depth_info_msg is not None
            )

    def get_rgb_image(self):
        """Return the latest RGB image as an H x W x 3 NumPy array."""
        with self._lock:
            message = self._rgb_msg

        if message is None:
            return None

        image = self.bridge.imgmsg_to_cv2(
            message,
            desired_encoding="rgb8",
        )
        return np.array(image, copy=True)

    def get_depth_image(self, meters=True):
        """Return the latest depth image, in meters by default."""
        with self._lock:
            message = self._depth_msg

        if message is None:
            return None

        depth = self.bridge.imgmsg_to_cv2(
            message,
            desired_encoding="passthrough",
        )
        depth = np.array(depth, copy=True)

        if not meters:
            return depth

        encoding = message.encoding.upper()
        if encoding in ("16UC1", "MONO16"):
            depth = depth.astype(np.float32) / 1000.0
        else:
            depth = depth.astype(np.float32)

        return depth

    def get_camera_info(self):
        """Return depth-camera calibration information as a dictionary."""
        with self._lock:
            info = self._depth_info_msg

        if info is None:
            return None

        return {
            "frame_id": info.header.frame_id,
            "width": int(info.width),
            "height": int(info.height),
            "fx": float(info.k[0]),
            "fy": float(info.k[4]),
            "cx": float(info.k[2]),
            "cy": float(info.k[5]),
            "distortion_model": info.distortion_model,
            "distortion": list(info.d),
        }

    def get_depth_at(self, x, y, window=1, method="median"):
        """Return depth at pixel (x, y), in meters."""
        depth = self.get_depth_image(meters=True)

        if depth is None:
            return None

        height, width = depth.shape[:2]
        x = int(x)
        y = int(y)
        window = max(1, int(window))

        if not (0 <= x < width and 0 <= y < height):
            raise ValueError("Pixel is outside the depth image")

        half = window // 2
        x0 = max(0, x - half)
        x1 = min(width, x + half + 1)
        y0 = max(0, y - half)
        y1 = min(height, y + half + 1)

        values = depth[y0:y1, x0:x1].reshape(-1)
        values = values[np.isfinite(values) & (values > 0.0)]

        if values.size == 0:
            return None
        if method == "min":
            return float(np.min(values))
        if method == "mean":
            return float(np.mean(values))
        if method == "median":
            return float(np.median(values))

        raise ValueError("method must be min, mean, or median")

    def get_center_depth(self, window=5, method="median"):
        """Return depth at the center of the image."""
        depth = self.get_depth_image(meters=True)
        if depth is None:
            return None

        height, width = depth.shape[:2]
        return self.get_depth_at(
            width // 2,
            height // 2,
            window=window,
            method=method,
        )

    def get_3d_point(self, x, y, window=3):
        """Convert a depth pixel to an XYZ point in the depth-camera frame."""
        info = self.get_camera_info()
        if info is None:
            return None

        z = self.get_depth_at(x, y, window=window, method="median")
        if z is None:
            return None

        fx = info["fx"]
        fy = info["fy"]
        cx = info["cx"]
        cy = info["cy"]

        if abs(fx) < 1e-9 or abs(fy) < 1e-9:
            return None

        x_3d = (float(x) - cx) * z / fx
        y_3d = (float(y) - cy) * z / fy
        return float(x_3d), float(y_3d), float(z)

    def get_point_cloud_xyz(self, max_points=5000, step=1):
        """Return sampled point-cloud coordinates as an N x 3 NumPy array."""
        if point_cloud2 is None:
            raise RuntimeError("sensor_msgs_py is not installed")

        with self._lock:
            cloud = self._pointcloud_msg

        if cloud is None:
            return None

        step = max(1, int(step))
        max_points = max(1, int(max_points))
        output = []

        for index, point in enumerate(
            point_cloud2.read_points(
                cloud,
                field_names=("x", "y", "z"),
                skip_nans=True,
            )
        ):
            if index % step != 0:
                continue

            x = float(point[0])
            y = float(point[1])
            z = float(point[2])

            if not (
                math.isfinite(x)
                and math.isfinite(y)
                and math.isfinite(z)
            ):
                continue

            output.append((x, y, z))
            if len(output) >= max_points:
                break

        return np.asarray(output, dtype=np.float32)

    def get_data(self) -> VisionData:
        """
        Return the latest RGB and depth data together, as a VisionData
        (rgb, depth, center_depth).

        The result is cached on this instance so a subsequent show() call
        (with no arguments) redraws it without needing another read.
        """

        data = VisionData(
            rgb=self.get_rgb_image(),
            depth=self.get_depth_image(),
            center_depth=self.get_center_depth(),
        )
        self._last_data = data
        return data

    def show(self) -> None:
        """
        Draw/update a live side-by-side view of the most recent get_data()
        result: RGB on the left, depth (colorized, 0-3m) on the right.

        Call this once per loop iteration, after get_data(). It returns
        immediately (non-blocking), so it's meant to be used inside a
        manually-timed control loop alongside motion/LiDAR calls -- the
        same pattern as MentorPi.set_velocity() / LidarSDK.show().

        Requires matplotlib:
            pip install matplotlib --break-system-packages
        """

        import matplotlib.pyplot as plt

        data = self._last_data

        if self._fig is None or not plt.fignum_exists(self._fig.number):
            plt.ion()
            self._fig, (self._rgb_axis, self._depth_axis) = plt.subplots(
                1, 2, figsize=(11, 5)
            )

            if self.window_position is not None:
                fig_width_px = self._fig.get_size_inches()[0] * self._fig.dpi
                fig_height_px = self._fig.get_size_inches()[1] * self._fig.dpi
                resolved = _resolve_window_position(
                    self.window_position, fig_width_px, fig_height_px
                )
                if resolved is not None:
                    _move_figure_window(self._fig, *resolved)

            rgb_placeholder = (
                data.rgb
                if data.rgb is not None
                else np.zeros((10, 10, 3), dtype=np.uint8)
            )
            depth_placeholder = (
                data.depth
                if data.depth is not None
                else np.zeros((10, 10), dtype=np.float32)
            )

            self._rgb_plot = self._rgb_axis.imshow(rgb_placeholder)
            self._depth_plot = self._depth_axis.imshow(
                depth_placeholder,
                vmin=0.0,
                vmax=3.0,
                cmap="rainbow",
            )

            self._rgb_axis.set_title("RGB")
            self._depth_axis.set_title("Depth")
            self._rgb_axis.axis("off")
            self._depth_axis.axis("off")

        if data.rgb is not None:
            self._rgb_plot.set_data(data.rgb)

        if data.depth is not None:
            self._depth_plot.set_data(data.depth)

        if data.center_depth is None:
            self._depth_axis.set_title("Depth | center: invalid")
        else:
            self._depth_axis.set_title(
                f"Depth | center: {data.center_depth:.3f} m"
            )

        self._fig.canvas.draw_idle()
        self._fig.canvas.flush_events()

    def close(self):
        """Stop the ROS executor and destroy the SDK node."""
        if self._closed:
            return

        self._closed = True
        self.executor.shutdown()
        self._spin_thread.join(timeout=1.0)
        self.executor.remove_node(self.node)
        self.node.destroy_node()

        if self._fig is not None:
            import matplotlib.pyplot as plt

            plt.close(self._fig)

        if self._owns_ros_context and rclpy.ok():
            rclpy.shutdown()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

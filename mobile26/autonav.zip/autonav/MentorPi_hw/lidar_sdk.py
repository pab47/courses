#!/usr/bin/env python3

import math
import threading
import time
from dataclasses import dataclass, field
from typing import List

import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan


@dataclass
class LidarPoints:
    """
    Detected LiDAR points, in the robot's own frame.

    x_data: meters ahead of the robot, one entry per detected point
    y_data: meters to the left (positive) / right (negative), same order
    angle_data: degrees, 0 = straight ahead, positive = counterclockwise
        (left), same order
    """

    x_data: List[float] = field(default_factory=list)
    y_data: List[float] = field(default_factory=list)
    angle_data: List[float] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.x_data)


_SCREEN_SIZE = None


def _get_screen_size():
    """Best-effort screen size lookup, in pixels. Falls back to a
    reasonable default if it can't be determined."""

    global _SCREEN_SIZE

    if _SCREEN_SIZE is None:
        try:
            import tkinter

            root = tkinter.Tk()
            root.withdraw()
            _SCREEN_SIZE = (root.winfo_screenwidth(), root.winfo_screenheight())
            root.destroy()
        except Exception:
            _SCREEN_SIZE = (1920, 1080)

    return _SCREEN_SIZE


def _resolve_window_position(position, fig_width_px, fig_height_px):
    """
    Resolve a window position into (x, y) pixel coordinates.

    position can be an explicit (x, y) pixel tuple, or one of the strings
    "top-left", "top-right", "bottom-left", "bottom-right".
    """

    if position is None:
        return None

    if isinstance(position, str):
        screen_width, screen_height = _get_screen_size()
        margin = 30

        corners = {
            "top-left": (margin, margin),
            "top-right": (screen_width - fig_width_px - margin, margin),
            "bottom-left": (margin, screen_height - fig_height_px - margin),
            "bottom-right": (
                screen_width - fig_width_px - margin,
                screen_height - fig_height_px - margin,
            ),
        }

        if position not in corners:
            raise ValueError(
                f"window_position string must be one of {list(corners)}, "
                f"got {position!r}"
            )

        return corners[position]

    # Assume an explicit (x, y) pixel tuple.
    return position


def _move_figure_window(fig, x, y):
    """Move a matplotlib figure window to a screen position, if the
    current backend supports it (TkAgg, Qt, and WX are covered; other
    backends silently do nothing)."""

    try:
        import matplotlib.pyplot as plt

        manager = fig.canvas.manager
        backend = plt.get_backend()

        if backend == "TkAgg":
            manager.window.wm_geometry(f"+{int(x)}+{int(y)}")
        elif backend in ("QtAgg", "Qt5Agg", "Qt4Agg"):
            manager.window.move(int(x), int(y))
        elif backend == "WXAgg":
            manager.window.SetPosition((int(x), int(y)))
    except Exception:
        pass  # Window positioning isn't supported by every backend/setup


class LidarSDK:
    """
    Very simple ROS 2 LiDAR SDK for MentorPi.

    The SDK subscribes to /scan_raw and stores the latest LaserScan.
    """

    def __init__(
        self,
        topic: str = "/scan_raw",
        field_of_view_degrees: float = 90.0,
        range_to_see_in_meters: float = 3.0,
        window_position=None,
    ):
        if not rclpy.ok():
            rclpy.init()

        self.node = Node("mentorpi_lidar_sdk")
        self.topic = topic

        # Default sweep settings used by get_data()/show() when called with
        # no arguments -- override per-call, or change these afterward.
        self.field_of_view_degrees = field_of_view_degrees
        self.range_to_see_in_meters = range_to_see_in_meters

        # Where to place the plot window on screen. Either an explicit
        # (x, y) pixel tuple, or one of "top-left", "top-right",
        # "bottom-left", "bottom-right". None leaves it wherever the
        # window manager puts it by default.
        self.window_position = window_position

        self._lock = threading.Lock()
        self._scan = None
        self._last_points = LidarPoints()

        # Lazily created the first time show() is called.
        self._fig = None
        self._ax = None

        self.subscription = self.node.create_subscription(
            LaserScan,
            self.topic,
            self._scan_callback,
            qos_profile_sensor_data,
        )

        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.node)

        self.running = True
        self.thread = threading.Thread(target=self._spin, daemon=True)
        self.thread.start()

    def _spin(self):
        while self.running and rclpy.ok():
            self.executor.spin_once(timeout_sec=0.1)

    def _scan_callback(self, message):
        with self._lock:
            self._scan = message

    def wait_for_scan(self, timeout=5.0):
        """Wait until the first LiDAR scan is received."""

        start_time = time.time()

        while time.time() - start_time < timeout:
            with self._lock:
                if self._scan is not None:
                    return True

            time.sleep(0.05)

        raise TimeoutError(
            f"No LiDAR data received from {self.topic} within {timeout} seconds"
        )

    def get_scan(self):
        """
        Return the latest LaserScan message.

        Returns None if no scan has been received.
        """

        with self._lock:
            return self._scan

    def get_ranges(self):
        """
        Return valid ranges as a list.

        Invalid NaN and infinite measurements are returned as None.
        """

        scan = self.get_scan()

        if scan is None:
            return []

        valid_ranges = []

        for distance in scan.ranges:
            if (
                math.isfinite(distance)
                and scan.range_min <= distance <= scan.range_max
            ):
                valid_ranges.append(float(distance))
            else:
                valid_ranges.append(None)

        return valid_ranges

    def get_distance(self, angle_degrees):
        """
        Return the LiDAR distance at an angle.

        Angle convention:
            0 degrees   = scan start direction
            90 degrees  = counterclockwise
            180 degrees = opposite direction
            270 degrees = clockwise

        Returns None when the reading is invalid.
        """

        scan = self.get_scan()

        if scan is None:
            return None

        angle_radians = math.radians(angle_degrees) % (2.0 * math.pi)

        index = round(
            (angle_radians - scan.angle_min) / scan.angle_increment
        )

        index %= len(scan.ranges)
        distance = float(scan.ranges[index])

        if (
            not math.isfinite(distance)
            or distance < scan.range_min
            or distance > scan.range_max
        ):
            return None

        return distance

    def get_points(self, max_distance=8.0):
        """
        Convert the latest scan to Cartesian x-y points.

        Returns:
            x_points, y_points
        """

        scan = self.get_scan()

        if scan is None:
            return [], []

        x_points = []
        y_points = []

        for index, distance in enumerate(scan.ranges):
            distance = float(distance)

            if not math.isfinite(distance):
                continue

            if distance < scan.range_min or distance > scan.range_max:
                continue

            if distance > max_distance:
                continue

            angle = scan.angle_min + index * scan.angle_increment

            x_points.append(distance * math.cos(angle))
            y_points.append(distance * math.sin(angle))

        return x_points, y_points

    def get_data(
        self,
        field_of_view_degrees: float = None,
        range_to_see_in_meters: float = None,
    ) -> LidarPoints:
        """
        Sweep a field of view centered on straight ahead (0 degrees) and
        return every detected point as a LidarPoints structure (x_data,
        y_data, angle_data), in the robot's own frame (x = forward,
        y = left).

        If field_of_view_degrees / range_to_see_in_meters are omitted, the
        values set on this instance (self.field_of_view_degrees /
        self.range_to_see_in_meters, from the constructor) are used.

        The result is cached on this instance so a subsequent show() call
        (with no arguments) redraws it without needing another get_data()
        call.
        """

        if field_of_view_degrees is None:
            field_of_view_degrees = self.field_of_view_degrees

        if range_to_see_in_meters is None:
            range_to_see_in_meters = self.range_to_see_in_meters

        scan = self.get_scan()

        if scan is None:
            self._last_points = LidarPoints()
            return self._last_points

        half_fov = field_of_view_degrees / 2.0
        points = LidarPoints()

        for index, distance in enumerate(scan.ranges):
            distance = float(distance)

            if not math.isfinite(distance):
                continue

            if distance < scan.range_min or distance > scan.range_max:
                continue

            if distance > range_to_see_in_meters:
                continue

            angle_radians = scan.angle_min + index * scan.angle_increment
            angle_degrees = math.degrees(angle_radians)

            # Normalize to (-180, 180] so the field-of-view check is
            # symmetric around straight ahead (0 degrees), regardless of
            # how the raw scan angles are laid out.
            angle_degrees = ((angle_degrees + 180.0) % 360.0) - 180.0

            if abs(angle_degrees) > half_fov:
                continue

            points.x_data.append(distance * math.cos(angle_radians))
            points.y_data.append(distance * math.sin(angle_radians))
            points.angle_data.append(angle_degrees)

        self._last_points = points
        return points

    def show(self) -> None:
        """
        Draw/update a live top-down, north-up plot of the most recent
        get_data() result.

        - The robot is fixed at (0, 0), facing +y (north / up the page).
        - Both axes run from -range_to_see_in_meters to
          +range_to_see_in_meters (using self.range_to_see_in_meters).
        - A shaded wedge shows the field_of_view cone that was swept
          (using self.field_of_view_degrees).

        Call this once per loop iteration, after get_data(). It returns
        immediately (non-blocking), so it's meant to be used inside a
        manually-timed control loop alongside motion commands -- the same
        pattern as MentorPi.set_velocity().

        Requires matplotlib:
            pip install matplotlib --break-system-packages
        """

        import matplotlib.pyplot as plt
        from matplotlib.patches import Wedge

        if self._fig is None or not plt.fignum_exists(self._fig.number):
            plt.ion()
            self._fig, self._ax = plt.subplots(figsize=(6, 6))

            if self.window_position is not None:
                fig_width_px = self._fig.get_size_inches()[0] * self._fig.dpi
                fig_height_px = self._fig.get_size_inches()[1] * self._fig.dpi
                resolved = _resolve_window_position(
                    self.window_position, fig_width_px, fig_height_px
                )
                if resolved is not None:
                    _move_figure_window(self._fig, *resolved)

        points = self._last_points
        half_fov = self.field_of_view_degrees / 2.0
        range_to_see_in_meters = self.range_to_see_in_meters

        # Rotate from the robot's own frame (x = forward, y = left) into
        # the plot's frame, where "forward" points up the page (+y /
        # north) and "left" points to the page's left.
        plot_x = [-y for y in points.y_data]
        plot_y = list(points.x_data)

        ax = self._ax
        ax.clear()

        cone = Wedge(
            (0, 0),
            range_to_see_in_meters,
            90 - half_fov,
            90 + half_fov,
            alpha=0.15,
            color="tab:blue",
        )
        ax.add_patch(cone)

        ax.scatter(plot_x, plot_y, s=10, c="tab:red", zorder=4)

        # Robot marker at the origin, pointing north (up the page).
        ax.scatter([0], [0], c="black", marker="^", s=120, zorder=5)

        ax.set_xlim(-range_to_see_in_meters, range_to_see_in_meters)
        ax.set_ylim(-range_to_see_in_meters, range_to_see_in_meters)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("meters (robot's left / right)")
        ax.set_ylabel("meters (robot's forward / back)")
        ax.set_title(
            f"LiDAR -- {len(points)} points, "
            f"fov={self.field_of_view_degrees:.0f} deg, "
            f"range={range_to_see_in_meters:.1f} m"
        )
        ax.grid(True)

        plt.pause(0.001)

    def close(self):
        """Stop the SDK, destroy its ROS node, and close any open plot."""

        self.running = False

        if self.thread.is_alive():
            self.thread.join(timeout=1.0)

        self.executor.remove_node(self.node)
        self.node.destroy_node()

        if self._fig is not None:
            import matplotlib.pyplot as plt

            plt.close(self._fig)

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        self.close()

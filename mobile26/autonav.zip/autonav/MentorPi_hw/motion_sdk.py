#!/usr/bin/env python3

import threading
import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
import math

from nav_msgs.msg import Odometry
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Imu


# Per-chassis capabilities. Add a new chassis type by adding one entry here —
# no other code needs to change.
#
#   can_strafe:          can move sideways (vy != 0)?
#   can_rotate_in_place:  can rotate with vx == 0 and vy == 0 (wz != 0)?
#   centers_wheels:      does stop() need to send a steering-centering pulse?
CHASSIS_CAPABILITIES = {
    "ackermann": {
        "can_strafe": False,
        "can_rotate_in_place": False,
        "centers_wheels": True,
    },
    "mecanum": {
        "can_strafe": True,
        "can_rotate_in_place": True,
        "centers_wheels": False,
    },
    "tank": {
        "can_strafe": False,
        "can_rotate_in_place": True,
        "centers_wheels": False,
    },
}

CHASSIS_TYPES = tuple(CHASSIS_CAPABILITIES.keys())


class MentorPi:

    def __init__(
        self,
        cmd_vel_topic: str = "/controller/cmd_vel",
        odom_topic: str = "/odom",
        imu_topic: str = "/imu",
        publish_rate: float = 20.0,
        chassis_type: str = "ackermann",
    ) -> None:

        if publish_rate <= 0:
            raise ValueError("publish_rate must be greater than zero")

        if chassis_type not in CHASSIS_CAPABILITIES:
            raise ValueError(
                f"chassis_type must be one of {CHASSIS_TYPES}, got {chassis_type!r}"
            )

        self.chassis_type = chassis_type
        self._capabilities = CHASSIS_CAPABILITIES[chassis_type]
        self.cmd_vel_topic = cmd_vel_topic
        self.publish_period = 1.0 / publish_rate
        self._closed = False
        self._command_lock = threading.Lock()
        self._owns_ros_context = not rclpy.ok()

        if self._owns_ros_context:
            rclpy.init()

        self.node = Node("mentorpi_python_sdk")

        self.publisher = self.node.create_publisher(
            Twist,
            cmd_vel_topic,
            10,
        )
        self.odom_topic = odom_topic
        self.imu_topic = imu_topic

        self._sensor_lock = threading.Lock()

        self._latest_odom = None
        self._latest_imu = None

        self.odom_subscription = self.node.create_subscription(
            Odometry,
            self.odom_topic,
            self._odom_callback,
            qos_profile_sensor_data,
        )

        self.imu_subscription = self.node.create_subscription(
            Imu,
            self.imu_topic,
            self._imu_callback,
            qos_profile_sensor_data,
        )

        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.node)

        self._spin_thread = threading.Thread(
            target=self.executor.spin,
            daemon=True,
        )
        self._spin_thread.start()

        self._wait_for_controller(timeout=2.0)

    def _wait_for_controller(self, timeout: float) -> bool:
        end_time = time.monotonic() + timeout

        while time.monotonic() < end_time:
            if self.publisher.get_subscription_count() > 0:
                return True

            time.sleep(0.05)

        self.node.get_logger().warning(
            f"No subscriber detected on {self.cmd_vel_topic}"
        )
        return False

    @staticmethod
    def _clamp(
        value: float,
        minimum: float,
        maximum: float,
    ) -> float:
        return max(minimum, min(value, maximum))

    def set_velocity(
        self,
        vx: float = 0.0,
        wz: float = 0.0,
        vy: float = 0.0,
    ) -> None:
        """
        Send one instant velocity command.

        vx: forward/backward speed (m/s, -2.0 to 2.0)
        wz: turning speed (rad/s, -1.0 to 1.0)
        vy: sideways/strafe speed (m/s, -2.0 to 2.0) — only accepted on
            chassis types where can_strafe is True.

        Which combinations of vx/vy/wz are physically possible depends on
        chassis_type; invalid combinations raise ValueError.
        """

        if self._closed:
            raise RuntimeError("The MentorPi SDK is closed")

        vx = self._clamp(vx, -2.0, 2.0)
        wz = self._clamp(wz, -1.0, 1.0)
        vy = self._clamp(vy, -2.0, 2.0)

        if not self._capabilities["can_strafe"] and abs(vy) > 1e-6:
            raise ValueError(
                f"{self.chassis_type} chassis cannot strafe (vy must be 0)"
            )

        if self.chassis_type == "ackermann":
            # --- FIX: The Micro-Value Trick ---
            # If moving forward/backward but requested angular velocity is 0,
            # send a tiny non-zero value to force the steering servo to
            # center. This is an Ackermann-specific hardware quirk, not a
            # general chassis capability.
            if abs(vx) > 1e-6 and abs(wz) < 1e-6:
                wz = 1e-5
            # ----------------------------------

        if (
            not self._capabilities["can_rotate_in_place"]
            and abs(vx) < 1e-6
            and abs(vy) < 1e-6
            and abs(wz) > 1e-6
        ):
            raise ValueError(
                f"{self.chassis_type} chassis cannot rotate in place"
            )

        message = Twist()
        message.linear.x = float(vx)
        message.linear.y = float(vy)
        message.angular.z = float(wz)

        with self._command_lock:
            self.publisher.publish(message)

    def _odom_callback(self, message: Odometry) -> None:
        with self._sensor_lock:
            self._latest_odom = message

    def _imu_callback(self, message: Imu) -> None:
        with self._sensor_lock:
            self._latest_imu = message

    def get_odometry(self) -> Odometry | None:
        """Return the most recently received Odometry message, or None."""
        with self._sensor_lock:
            return self._latest_odom

    def get_imu(self) -> Imu | None:
        """Return the most recently received Imu message, or None."""
        with self._sensor_lock:
            return self._latest_imu

    def get_pose(self, degrees: bool = False):
        """
        Return the robot pose from odometry.

        Returns:
            x, y, yaw

        yaw is returned in radians by default.
        """

        with self._sensor_lock:
            odom = self._latest_odom

        if odom is None:
            return None

        position = odom.pose.pose.position
        orientation = odom.pose.pose.orientation

        rpy = self._quaternion_to_rpy(
            orientation.x,
            orientation.y,
            orientation.z,
            orientation.w,
        )

        if rpy is None:
            return None

        _, _, yaw = rpy

        if degrees:
            yaw = math.degrees(yaw)

        return (
            float(position.x),
            float(position.y),
            float(yaw),
        )

    def get_velocity(self):
        """
        Return measured robot velocity from odometry.

        Returns:
            vx, wz

        vx is in meters per second.
        wz is in radians per second.
        """

        with self._sensor_lock:
            odom = self._latest_odom

        if odom is None:
            return None

        return (
            float(odom.twist.twist.linear.x),
            float(odom.twist.twist.linear.y),
            float(odom.twist.twist.angular.z),
        )

    def get_roll_pitch_yaw(self, degrees: bool = False):
        """
        Return roll, pitch, and yaw from the IMU.

        Values are returned in radians by default.
        """

        with self._sensor_lock:
            imu = self._latest_imu

        if imu is None:
            return None

        # A value of -1 means orientation is unavailable.
        if (
            len(imu.orientation_covariance) > 0
            and imu.orientation_covariance[0] == -1.0
        ):
            return None

        orientation = imu.orientation

        rpy = self._quaternion_to_rpy(
            orientation.x,
            orientation.y,
            orientation.z,
            orientation.w,
        )

        if rpy is None:
            return None

        if degrees:
            return tuple(math.degrees(value) for value in rpy)

        return rpy

    def get_angular_velocity(self):
        """
        Return IMU angular velocity.

        Returns:
            wx, wy, wz

        Units are radians per second.
        """

        with self._sensor_lock:
            imu = self._latest_imu

        if imu is None:
            return None

        angular = imu.angular_velocity

        return (
            float(angular.x),
            float(angular.y),
            float(angular.z),
        )

    def get_linear_acceleration(self):
        """
        Return IMU linear acceleration.

        Returns:
            ax, ay, az

        Units are meters per second squared.
        """

        with self._sensor_lock:
            imu = self._latest_imu

        if imu is None:
            return None

        acceleration = imu.linear_acceleration

        return (
            float(acceleration.x),
            float(acceleration.y),
            float(acceleration.z),
        )

    @staticmethod
    def _quaternion_to_rpy(
        x: float,
        y: float,
        z: float,
        w: float,
    ):
        """
        Convert quaternion orientation to roll, pitch, and yaw.

        Returns radians as a tuple (roll, pitch, yaw), or None if the
        quaternion is degenerate (near-zero norm).
        """

        quaternion_norm = math.sqrt(
            x * x + y * y + z * z + w * w
        )

        if quaternion_norm < 1e-9:
            return None

        # Normalize
        x /= quaternion_norm
        y /= quaternion_norm
        z /= quaternion_norm
        w /= quaternion_norm

        # Roll (x-axis rotation)
        sinr_cosp = 2.0 * (w * x + y * z)
        cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)

        # Pitch (y-axis rotation)
        sinp = 2.0 * (w * y - z * x)
        if abs(sinp) >= 1.0:
            pitch = math.copysign(math.pi / 2.0, sinp)
        else:
            pitch = math.asin(sinp)

        # Yaw (z-axis rotation)
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        return roll, pitch, yaw

    def move_for(
        self,
        vx: float = 0.0,
        wz: float = 0.0,
        duration: float = 1.0,
        vy: float = 0.0,
    ) -> None:
        """
        Drive at the given velocity for `duration` seconds, publishing at
        `publish_period` intervals, then always stop (even on error/interrupt).

        `vy` (sideways/strafe speed) is only accepted on chassis types with
        can_strafe=True (currently mecanum); it will raise ValueError
        otherwise.
        """
        end_time = time.monotonic() + duration

        try:
            while time.monotonic() < end_time:
                self.set_velocity(vx=vx, wz=wz, vy=vy)
                time.sleep(self.publish_period)
        finally:
            self.stop()

    def forward(
        self,
        speed: float = 0.10,
        duration: float = 1.0,
    ) -> None:
        self.move_for(
            duration=duration,
            vx=abs(speed),
        )

    def backward(
        self,
        speed: float = 0.10,
        duration: float = 1.0,
    ) -> None:
        self.move_for(
            duration=duration,
            vx=-abs(speed),
        )

    def turn_left(
        self,
        speed: float = 0.10,
        angular_speed: float = 0.25,
        duration: float = 1.0,
    ) -> None:
        self.move_for(
            duration=duration,
            vx=abs(speed),
            wz=abs(angular_speed),
        )

    def turn_right(
        self,
        speed: float = 0.10,
        angular_speed: float = 0.25,
        duration: float = 1.0,
    ) -> None:
        self.move_for(
            duration=duration,
            vx=abs(speed),
            wz=-abs(angular_speed),
        )

    def strafe_left(
        self,
        speed: float = 0.10,
        duration: float = 1.0,
    ) -> None:
        """Move sideways to the left. Requires a chassis with can_strafe=True."""
        if not self._capabilities["can_strafe"]:
            raise RuntimeError(
                f"strafe_left() is not supported on chassis_type={self.chassis_type!r}"
            )
        self.move_for(
            duration=duration,
            vy=abs(speed),
        )

    def strafe_right(
        self,
        speed: float = 0.10,
        duration: float = 1.0,
    ) -> None:
        """Move sideways to the right. Requires a chassis with can_strafe=True."""
        if not self._capabilities["can_strafe"]:
            raise RuntimeError(
                f"strafe_right() is not supported on chassis_type={self.chassis_type!r}"
            )
        self.move_for(
            duration=duration,
            vy=-abs(speed),
        )

    def rotate_left(
        self,
        angular_speed: float = 0.25,
        duration: float = 1.0,
    ) -> None:
        """Rotate in place, counter-clockwise. Requires a chassis with
        can_rotate_in_place=True."""
        if not self._capabilities["can_rotate_in_place"]:
            raise RuntimeError(
                f"rotate_left() is not supported on chassis_type={self.chassis_type!r} "
                "(this chassis cannot rotate in place)"
            )
        self.move_for(
            duration=duration,
            wz=abs(angular_speed),
        )

    def rotate_right(
        self,
        angular_speed: float = 0.25,
        duration: float = 1.0,
    ) -> None:
        """Rotate in place, clockwise. Requires a chassis with
        can_rotate_in_place=True."""
        if not self._capabilities["can_rotate_in_place"]:
            raise RuntimeError(
                f"rotate_right() is not supported on chassis_type={self.chassis_type!r} "
                "(this chassis cannot rotate in place)"
            )
        self.move_for(
            duration=duration,
            wz=-abs(angular_speed),
        )

    def stop(self, duration: float = 0.5) -> None:

        if self._closed:
            return

        message = Twist()
        message.linear.x = 0.0
        message.linear.y = 0.0

        if self._capabilities["centers_wheels"]:
            # --- FIX: Center Wheels on Stop ---
            # Force steering servo to center when coming to a halt.
            message.angular.z = 1e-5
            # ----------------------------------
        else:
            message.angular.z = 0.0

        end_time = time.monotonic() + duration

        while time.monotonic() < end_time:
            with self._command_lock:
                self.publisher.publish(message)

            time.sleep(self.publish_period)

    def close(self) -> None:

        if self._closed:
            return

        try:
            self.stop()
        finally:
            self._closed = True

            self.executor.shutdown()
            self._spin_thread.join(timeout=1.0)

            self.executor.remove_node(self.node)
            self.node.destroy_node()

            if self._owns_ros_context and rclpy.ok():
                rclpy.shutdown()

    def __enter__(self) -> "MentorPi":
        return self

    def __exit__(self, *args) -> None:
        self.close()

function [x, y, table] = euler(dydx, x0, y0, x_end, dx)
    % EULER Method for solving ODEs
    % dydx  - function handle for the differential equation dy/dx = f(x, y)
    % x0    - initial value of x
    % y0    - initial value of y at x0
    % x_end - final value of x
    % dx    - step size for integration

    % Create array of x values from x0 to x_end with step size dx
    x = x0:dx:x_end;

    % Initialize array for y values
    y = zeros(size(x));

    % Set the initial condition
    y(1) = y0;

    table = [];
    % Euler method loop
    for i = 1:length(x) - 1
        dydx_value = dydx(x(i), y(i));  % Compute dy/dx at the current point
        y(i+1) = y(i) + dx * dydx_value;  % Apply Euler's formula
        table = [table; x0+(i-1)*dx y(i) dx * dydx_value y(i+1)];
    end
end


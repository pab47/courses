clc
clear all
%format long

pkg load symbolic
syms x
#taylor_series = taylor(sin(x), x, 'Order', 8);
#value = double(subs(taylor_series, x, 0.1));  % Substitute x = 0.1 and convert to double
#disp(value);  % Display the numerical result


taylor_series = taylor(sin(x), x, 'Order', 2);
value = double(subs(taylor_series, x, 0.1));  % Substitute x = 0.1 and convert to double
disp(value);  % Display the numerical result




delete output.txt
diary output.txt
f = @(x) x^2 - 3*x;
dfdx = @(x) 2*x - 3;
a = 4; % Initial upper guess
tol = 1e-3; % Tolerance for stopping criterion
max_iter = 100; % Maximum number of iterations

root = newtonRaphson(f, dfdx, a, tol, max_iter);

fprintf('The root is approximately: %.4f\n', root);

diary off

function root = newtonRaphson(f, dfdx, a, tol, max_iter)

fa = f(a);
iter = 0;
while (abs(fa)>tol)

  %x2 = x1 - f(x1)/dfdx(x1);
   b = a - f(a)/dfdx(a);
   iter = iter+1;

   a = b;
   fa = f(a);

   % Print progress of each iteration using disp
    disp(['Iteration ', num2str(iter), ': a = ', num2str(a), ...
          ', f(a) = ', num2str(f(a))]);

    if (iter>max_iter)
      disp('Method reached maximum iteration limit. Solution may not be accurate');
      break;
    endif

end

root = a;

disp(['iteration = ',num2str(iter)])



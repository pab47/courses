% Example usage
delete output.txt
diary output.txt
f = @(x) x^2 - 3*x;
a = 1; % Initial lower guess
b = 4; % Initial upper guess
tol = 1e-3; % Tolerance for stopping criterion
max_iter = 100; % Maximum number of iterations

root = regularFalsi(f, a, b, tol, max_iter);
fprintf('The root is approximately: %.4f\n', root);

diary off



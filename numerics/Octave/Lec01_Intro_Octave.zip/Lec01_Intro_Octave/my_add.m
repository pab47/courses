function my_sum = my_add(vector)

n = length(vector);

my_sum = 0;
for i=1:n
  my_sum = my_sum + vector(i);
end



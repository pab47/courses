%Comment
%This code will sum the elements of a vector
% e.g. a = [1 1 2 3]; sum(a) = 7

clc
clear all

a = [1 1 2 3];
b = [5 4 3]';
sum = my_add(a)
sum = my_add(b)

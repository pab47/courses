% Define the augmented matrix

delete output.txt
diary output.txt
b = [7; -2; 3];
A = [
    2 1 1;
    1 -3 1;
    2 2 -1;
];

disp(A\b)

disp(' ')
% Call the Gauss-Jordan function
Ainv = gauss_jordan_inverse(A)

% Display the result

x = Ainv*b
diary off

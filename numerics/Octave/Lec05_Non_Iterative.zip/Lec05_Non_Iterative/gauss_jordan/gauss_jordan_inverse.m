function Ainv = gauss_jordan_inverse(A)
  % Augment the matrix A with the column vector b
  [row,col] = size(A);
  A_aug = [A eye(row,row) ];
  [rows, cols] = size(A_aug);

  % Forward elimination with partial pivoting
  for i = 1:rows
    % Partial pivoting: Find the maximum element in the current column (i)
    [~, pivot_row] = max(abs(A_aug(i:rows, i)));
    pivot_row = pivot_row + i - 1;

    % Swap the current row with the row having the largest pivot element
    if pivot_row ~= i
      A_aug([i, pivot_row], :) = A_aug([pivot_row, i], :);
    end

    % Make the diagonal element 1 (pivot normalization)
    A_aug(i, :) = A_aug(i, :) / A_aug(i, i);

    % Make the other elements in the same column 0
    for j = 1:rows
      if j ~= i
        A_aug(j, :) = A_aug(j, :) - A_aug(j, i) * A_aug(i, :);
      end
    end
  end

  % Solution is the last column after reduction
  %x = A_aug(:, cols);
  Ainv = A_aug(:,col+1:end);
end


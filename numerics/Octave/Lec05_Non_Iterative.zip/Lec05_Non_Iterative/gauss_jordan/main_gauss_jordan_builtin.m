% Define the augmented matrix
A = [
    2 1 1 7;
    1 -3 1 -2;
    2 2 -1 3;
];

% Perform Gauss-Jordan elimination (reduced row echelon form)
rref_A = rref(A);

% Display the result
disp(rref_A);


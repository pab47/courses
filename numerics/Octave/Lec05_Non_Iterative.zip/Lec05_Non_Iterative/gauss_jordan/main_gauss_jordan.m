% Define the augmented matrix

diary output.txt
b = [7; -2; 3];
A = [
    2 1 1;
    1 -3 1;
    2 2 -1;
];

disp(A\b)

disp(' ')
% Call the Gauss-Jordan function
solution = gauss_jordan(A,b);

% Display the result
disp(solution);
diary off

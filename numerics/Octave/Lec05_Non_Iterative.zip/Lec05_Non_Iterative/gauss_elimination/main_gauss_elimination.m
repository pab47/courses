clc
clear all

% Coefficient matrix A and right-hand side vector b
A = [2 1 1; 1 -3 1; 2 2 -1];
b = [7; -2; 3];

x = A\b

% Call the Gaussian elimination function
x = gauss_elimination(A, b);

% Display the solution
disp('Solution for x1, x2, x3:');
disp(x);


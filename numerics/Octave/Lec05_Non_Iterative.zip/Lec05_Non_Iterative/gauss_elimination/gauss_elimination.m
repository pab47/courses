function x = gauss_elimination(A, b)
    % Augmented matrix
    augmented_matrix = [A b];

    % Number of equations
    n = size(A, 1);

    % Gaussian Elimination (forward elimination)
    for i = 1:n-1
        for j = i+1:n
            factor = augmented_matrix(j,i) / augmented_matrix(i,i);
            augmented_matrix(j,:) = augmented_matrix(j,:) - factor * augmented_matrix(i,:);
        end
    end

    % Back substitution
    x = zeros(n,1);
    x(n) = augmented_matrix(n,end) / augmented_matrix(n,n);

    for i = n-1:-1:1
        x(i) = (augmented_matrix(i,end) - augmented_matrix(i,i+1:n) * x(i+1:n)) / augmented_matrix(i,i);
    end
end


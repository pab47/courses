clc
clear all

diary output.txt
% Coefficient matrix A and right-hand side vector b
A = [0 1 1; 2 1 0; 1 2 1];
b = [3; 8; 8];

x = A\b

% Call the Gaussian elimination function
x = gauss_elimination_w_pivoting(A, b);

% Display the solution
disp('Solution for x1, x2, x3:');
disp(x);
diary off


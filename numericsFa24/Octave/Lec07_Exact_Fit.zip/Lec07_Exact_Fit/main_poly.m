clc
clear all
close all

x = [0 1 2]
y = [2 0 4]

p = polyfit(x,y,2)

plot(x,y,'ro'); hold on

xfit = linspace(0,2);
yfit = polyval(p,xfit);
#yfit = 2-5*xfit+3*xfit.^2;
plot(xfit,yfit)

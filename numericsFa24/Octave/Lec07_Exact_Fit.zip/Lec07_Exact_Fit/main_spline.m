clc
clear all
close all

x = [1 2 3 4];
y = [3,6,5,8]; %f(x)

xfit = linspace(1,4);
#yfit = spline(x,y,xfit); #not-a-knot
#yfit = spline(x,[0 y 0],xfit); #clamped condition

pp = spline(x,[0 y 0]);
yfit = ppval(pp,xfit);

plot(x,y,'rx'); hold on
plot(xfit,yfit,'k-')





function finite_diff
format long

f = @(x) cos(x);      % Define a function f(x) = x^2
x = pi/6;             % Point at which to evaluate the derivative
h = 0.01;          % Step size

disp('using step size of 0.01');
df_forward = forward_difference(f, x, h)
df_backward = backward_difference(f, x, h)
df_central = central_difference(f, x, h)

h = 0.0001;
disp('using step size of 0.0001');
df_forward = forward_difference(f, x, h)
df_backward = backward_difference(f, x, h)
df_central = central_difference(f, x, h)

end

function df = forward_difference(f, x, h)
    df = (f(x + h) - f(x)) / h;
end

function df = backward_difference(f, x, h)
    df = (f(x) - f(x - h)) / h;
end

function df = central_difference(f, x, h)
    df = (f(x + h) - f(x - h)) / (2 * h);
end



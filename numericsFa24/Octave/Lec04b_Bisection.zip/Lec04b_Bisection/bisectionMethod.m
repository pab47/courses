function root = bisectionMethod(f, a, b, tol, max_iter)
  % Bisection Method to find the root of a given function f(x)
  % Inputs:
  % f - function handle representing f(x)
  % a - initial guess for lower bound
  % b - initial guess for upper bound
  % tol - tolerance for stopping criterion (default: 1e-3)
  % max_iter - maximum number of iterations to perform

  % Check if initial guesses enclose the root
  if f(a) * f(b) > 0
    error('The initial interval does not bracket a root');
  endif

  iter = 0;

  string = [];
  % Bisection method loop
  while (abs(f((a + b) / 2)) > tol && iter < max_iter)
    % Calculate midpoint
    c = (a + b) / 2;

    % Print progress of each iteration using disp
    disp(['Iteration ', num2str(iter), ': a = ', num2str(a), ...
          ', b = ', num2str(b), ', c = ', num2str(c), ...
          ', f(c) = ', num2str(f(c))]);
    %pause(1)
        %fprintf('Iteration %d: a = %.4f, b = %.4f, c = %.4f, f(c) = %.4f\n', iter, a, b, c, f(c));
    %string = [string; ['Iteration %d: a = %.4f, b = %.4f, c = %.4f, f(c) = %.4f\n', iter, a, b, c, f(c))]];


    % Check if the root is at the midpoint
    if abs(f(c)) < tol
      root = c;
      return;
    endif

    % Decide which subinterval to use for the next iteration
    if f(a) * f(c) < 0
      b = c;
    else
      a = c;
    endif

    iter = iter + 1;
  endwhile

  % Return the root approximation
  root = (a + b) / 2;

  % Check if the method converged
  if iter == max_iter
    disp('Maximum number of iterations reached without convergence.');
  else
    fprintf('Converged in %d iterations\n', iter);
  endif
endfunction



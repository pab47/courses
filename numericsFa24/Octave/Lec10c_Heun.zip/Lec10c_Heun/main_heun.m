% Main script to call Euler method
clear;
clc;
close all

% Define the differential equation as a function handle
dydx = @(x, y) -3 * y;

% Initial conditions and parameters
x0 = 0;     % Initial x value
y0 = 1;     % Initial condition y(0) = 1
x_end = 1;  % Final x value
dx = 0.1;   % Step size

% Call the Euler method function
[x, y,table] = heun(dydx, x0, y0, x_end, dx);

% Display results
%disp([x' y'])
disp(table)

% Optionally, plot the result
plot(x, y, '-o');
xlabel('x');
ylabel('y');
title('Euler''s Method: dy/dx = -3y');
grid on;


clc
clear all
close all

load('poly1.mat');

[x' y'];

%hand calculation
a = 1.9485;
b = 0.6595;

xfit = linspace(-2,2);
yfit = poly1(xfit,a,b);

#fminunc
c0 = [1,1];
%E = myfun(c0,x,y)
[c,fval] = fminunc(@(c)myfun(c,x,y),c0)
yfit2 = poly1(xfit,c(1),c(2));

figure(1)
subplot(2,1,1);
plot(x,y,'bo'); hold on
plot(xfit,yfit,'r-','Linewidth',2)
subplot(2,1,2);
plot(x,y,'bo'); hold on
plot(xfit,yfit2,'k-','Linewidth',2)

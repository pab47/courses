function y = poly1(x,a,b)
  y = a*x+b;


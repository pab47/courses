function E = myfun(c,x,y)
  a = c(1);
  b = c(2);
  %E = sum(y-ax-b)
  %E = sum((y - a*x - b).^2)
  E = 0;
  for i=1:length(x)
    E = E + (y(i) - poly1(x(i),a,b))^2;
    %E = E + (y(i)-a*x(i)-b)^2;
  endfor


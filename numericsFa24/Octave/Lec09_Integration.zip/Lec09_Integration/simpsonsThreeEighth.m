function I = simpsonsThreeEighth(f, a, b, n)

if (mod(n,3)==1)
  n = n+2;
  #disp('Simpson 3/8: n not multiple of 3, adding 2 more');
end
if (mod(n,3)==2)
  n = n+1;
  #disp('Simpson 3/8: n not multiple of 3, adding 1 more');
end

h = (b - a) / n;  % Subinterval width
x = a:h:b;  % x-values
y = f(x);  % y-values

I = (3 * h / 8) * (y(1) + y(end) + 3 * (sum(y(2:3:end-2))+sum(y(3:3:end-1)))+ ...
        2 * sum(y(4:3:end-3)));  % Simpson's 3/8 rule formula
        
end

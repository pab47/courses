clc
clear all

f = @(x) x.^2;
int_f = @(x) x^3/3;

a = 0;
b = 1;
n = 6;
%%%% part c
I_analytic = int_f(b) - int_f(a)

#Example 1
%%%  part a
I_lower = rectangular_lower(f,a,b,n)

%%%  part a
I_upper = rectangular_upper(f,a,b,n)

%%% part b
I_trap = trapezoidal(f,a,b,n)

%% Example 2
I_simpson13 = simpsonsOneThird(f, a, b, n)

I_simpson38 = simpsonsThreeEighth(f, a, b, n)




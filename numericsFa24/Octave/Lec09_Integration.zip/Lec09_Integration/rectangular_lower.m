function I_lower = rectangular_lower(f,a,b,n)

dx = (b-a)/n;
xi = a:dx:b;

fi = f(xi);
I_lower = dx*sum(fi(1:end-1));





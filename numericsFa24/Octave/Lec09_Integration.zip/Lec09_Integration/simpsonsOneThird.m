function I = simpsonsOneThird(f, a, b, n)

if (mod(n,2)~=0)
  n = n+1;
  #disp('Simpson 1/3: n is odd, increased n by 1 to make it even');
end
h = (b - a) / n;  % Subinterval width
x = a:h:b;  % x-values
y = f(x);  % y-values

I = (h/3) * (y(1) + y(end) + 4*sum(y(2:2:end-1)) + 2*sum(y(3:2:end-2)));  % Simpson's 1/3 rule formula
end

function I_upper = rectangular_upper(f,a,b,n)

dx = (b-a)/n;
xi = a:dx:b;

fi = f(xi);
I_upper = dx*sum(fi(2:end));





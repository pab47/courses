% jacobi_iterative.m

function [x, iter] = jacobi_iterative(A, b, x0, tol, max_iter)
    % Function to solve the system of linear equations Ax = b using the Jacobi iterative method.
    % Inputs:
    % A        - Coefficient matrix
    % b        - Right-hand side vector
    % x0       - Initial guess for the solution
    % tol      - Tolerance for convergence
    % max_iter - Maximum number of iterations
    % Outputs:
    % x        - Solution vector
    % iter     - Number of iterations performed

    n = length(b);  % Size of the system
    x = x0;         % Initialize solution vector
    iter = 0;       % Initialize iteration counter

    % Iterate until convergence or maximum number of iterations is reached
    for k = 1:max_iter
        x_new = zeros(n, 1);  % Initialize new solution vector

        % Update each component of the solution vector
        for i = 1:n
            sum1 = 0;
            for j = 1:n
                if j ~= i
                    sum1 = sum1 + A(i, j) * x(j);
                end
            end
            x_new(i) = (b(i) - sum1) / A(i, i);
        end

        if (iter < 3)
          disp(['x1 = ',num2str(x_new(1)),' x2 = ',num2str(x_new(2)),' x3 = ',num2str(x_new(3))])
        endif

        % Check for convergence
        if norm(x_new - x, 2) < tol
            x = x_new;
            iter = k;
            return;
        end

        % Update the solution for the next iteration
        x = x_new;
        iter = k;
    end

    #warning('Maximum number of iterations reached without convergence.');
end


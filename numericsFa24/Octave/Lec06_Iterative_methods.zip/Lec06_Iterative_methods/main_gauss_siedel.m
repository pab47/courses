% main.m
format long

% Coefficient matrix A
A = [2 1 1;
     1 -3 1;
     2 2 -1];

% Right-hand side vector b
b = [7; -2; 3];

% Initial guess for the solution
x0 = [0; 0; 0];  % You can change the initial guess

% Tolerance and maximum number of iterations
tol = 1e-3;
max_iter = 1000;

% Call the Jacobi iterative solver
[x, iter] = gauss_siedel(A, b, x0, tol, max_iter);

% Display the result
disp('Solution vector x:');
disp(x);

disp(['Number of iterations: ', num2str(iter)]);

